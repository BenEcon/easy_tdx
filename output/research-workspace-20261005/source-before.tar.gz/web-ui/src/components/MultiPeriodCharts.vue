<script setup lang="ts">
import { computed, nextTick, onBeforeUnmount, shallowRef, ref, watch } from 'vue'
import { fetchResearchSnapshot, replayChanlun, formatError, type BarSnapshot } from '../api'
import { targetIdentity, type ResearchTarget } from '../chanlun-target'
import { alignPeriodSnapshots, comparisonPeriods, periodLabel } from '../period-comparison'
import type { AdjustMode, Bar, Category, ChanlunResult } from '../types'
import type { ChanlunLineWidths } from '../chanlun-line-width'
import type { DivergenceFocus } from '../divergence-focus'
import ChartFrame from './ChartFrame.vue'
import ChanlunChart from './ChanlunChart.vue'
import MacSelect from './MacSelect.vue'

const props = defineProps<{
  target: ResearchTarget; title: string; adjust: AdjustMode; asOf: string; busy: boolean
  primaryCategory: Category; primaryBars: Bar[]; primaryMetadata: BarSnapshot['metadata']; primaryResult: ChanlunResult; count: number
  layers: { bis: boolean; zss: boolean; xds: boolean; mmds: boolean; bcs: boolean; consolidations?: boolean; nextPen?: boolean }
  maPeriods: number[]; maAvailablePeriods: number[]; lineWidths: ChanlunLineWidths; candleTransparency: number
  showDivergenceHistory: boolean; focus?: DivergenceFocus | null
}>()
const emit = defineEmits<{ 'update:maPeriods': [periods: number[]] }>()
const selected = ref<Category>(props.primaryCategory === 'MIN_30' ? 'DAY' : 'MIN_30')
const options = computed(() => comparisonPeriods.filter(item => item.value !== props.primaryCategory))
const mode = ref<'primary' | 'other' | 'compare'>('primary')
const loading = ref(false)
const error = ref('')
const notice = ref('')
type ChartData = { category: Category; bars: Bar[]; result: ChanlunResult; excluded: number }
const comparison = shallowRef<{ cutoff: string; primary: ChartData; other: ChartData } | null>(null)
const charts = computed(() => !comparison.value || mode.value === 'primary' ? []
  : mode.value === 'other' ? [comparison.value.other] : [comparison.value.primary, comparison.value.other])
let generation = 0
function invalidate() {
  if (comparison.value || loading.value) notice.value = '分析条件或回放时刻已变化，请重新生成周期对比。'
  generation++; comparison.value = null; loading.value = false; error.value = ''; mode.value = 'primary'
}
watch([() => targetIdentity(props.target), () => props.adjust, () => props.asOf, () => props.primaryCategory,
  () => props.primaryBars, () => props.primaryMetadata, () => props.count, selected], invalidate, { flush: 'sync' })
watch(() => props.primaryCategory, value => { if (selected.value === value) selected.value = value === 'MIN_30' ? 'DAY' : 'MIN_30' })
watch(() => props.focus, value => { if (value) mode.value = 'primary' })
watch(mode, () => { void nextTick(() => window.dispatchEvent(new Event('resize'))) })
onBeforeUnmount(() => { generation++ })

async function generate() {
  const version = ++generation
  const instrument = { ...props.target }
  const identity = targetIdentity(instrument)
  const category = selected.value, primaryCategory = props.primaryCategory
  const primary: BarSnapshot = { bars: props.primaryBars, metadata: props.primaryMetadata }
  const originalResult = props.primaryResult
  const asOf = props.asOf, adjust = props.adjust, count = props.count
  loading.value = true; error.value = ''; notice.value = ''; comparison.value = null; mode.value = 'primary'
  try {
    const snapshot = await fetchResearchSnapshot(instrument, category, count, adjust)
    if (version !== generation) return
    const aligned = alignPeriodSnapshots(primary, snapshot, asOf, adjust)
    if (!aligned.primary.bars.length) throw new Error('主周期在共同截止前没有已收盘 K 线，暂不能对比')
    if (!aligned.other.bars.length) throw new Error(`${periodLabel(category)}在共同截止前没有已收盘 K 线。可向后回放或扩大历史窗口后重试。`)
    // Keep the original warm-up start; only remove unavailable suffix candles.
    const primaryResult = aligned.primary.excluded === 0 ? originalResult
      : await replayChanlun({ code: identity, category: primaryCategory, bars: aligned.primary.bars, visible_count: aligned.primary.bars.length })
    if (version !== generation) return
    const otherResult = await replayChanlun({ code: identity, category, bars: aligned.other.bars, visible_count: aligned.other.bars.length })
    if (version !== generation) return
    comparison.value = { cutoff: aligned.cutoff,
      primary: { ...aligned.primary, category: primaryCategory, result: primaryResult },
      other: { ...aligned.other, category, result: otherResult } }
    mode.value = 'compare'
  } catch (err) { if (version === generation) error.value = formatError(err) }
  finally { if (version === generation) loading.value = false }
}
const shortTime = (value: string) => value.replace('T', ' ').replace(' 00:00:00', '')
function rangeText(chart: ChartData) {
  return `${shortTime(chart.bars[0]!.datetime)} — ${shortTime(chart.bars.at(-1)!.period_end!)} · ${chart.bars.length} 根已收盘${chart.excluded ? ` · 排除 ${chart.excluded} 根未收盘或截止后行情` : ''}`
}
</script>

<template>
  <section class="period-charts" aria-label="多周期图表对比" :aria-busy="loading">
    <div class="period-tools">
      <div class="period-heading"><strong>多周期图表</strong><span>主周期 <b>{{ periodLabel(primaryCategory) }}</b></span></div>
      <div class="period-selection">
        <span class="period-selection-label">对照周期</span>
        <MacSelect v-model="selected" :options="options" aria-label="对照周期" :disabled="busy" />
        <button class="period-generate" :disabled="busy || loading || !asOf" @click="generate">{{ loading ? '计算中…' : comparison ? '重新生成' : '生成对比' }}</button>
      </div>
    </div>
    <div v-if="comparison" class="period-viewbar">
      <div class="period-modes" role="group" aria-label="周期图表显示方式">
        <button :aria-pressed="mode === 'primary'" @click="mode = 'primary'">主周期 · {{ periodLabel(primaryCategory) }}</button>
        <button :aria-pressed="mode === 'other'" @click="mode = 'other'">仅看 {{ periodLabel(comparison.other.category) }}</button>
        <button :aria-pressed="mode === 'compare'" @click="mode = 'compare'">上下对比</button>
      </div>
      <span class="period-cutoff">共同截止 <time>{{ comparison.cutoff }}</time></span>
    </div>
    <p v-if="error" class="period-error" role="alert">{{ error }}</p>
    <p v-else-if="loading" class="period-note" role="status">正在计算所选周期的独立结构，主图仍可查看…</p>
    <p v-else-if="!comparison" class="period-note" role="status">{{ notice || '选择另一个周期，查看同一标的的独立分析，或与主周期上下对比。' }}</p>
    <p v-else-if="mode !== 'primary'" class="period-note">仅纳入共同截止前的已收盘 K 线，各周期独立计算、独立缩放；历史覆盖范围可能不同。下方结构明细仍对应左侧主周期。</p>
    <div v-show="mode === 'primary' || !comparison" class="period-primary"><slot /></div>
    <div v-if="charts.length" class="period-comparison">
      <ChartFrame v-for="chart in charts" :key="chart.category" :title="`${title} · ${periodLabel(chart.category)}`" :description="rangeText(chart)">
        <template #actions><span class="period-chart-label">{{ chart.category === primaryCategory ? '主周期 · 收盘快照' : '对照周期' }}</span></template>
        <ChanlunChart :bars="chart.bars" :result="chart.result" :layers="layers" :show-divergence-history="showDivergenceHistory"
          :ma-periods="maPeriods" :ma-available-periods="maAvailablePeriods" :line-widths="lineWidths" :candle-transparency="candleTransparency"
          @update:ma-periods="emit('update:maPeriods', $event)" />
      </ChartFrame>
    </div>
  </section>
</template>

<style scoped>
.period-charts { min-width: 0; width: 100%; }
.period-tools, .period-viewbar { display: flex; align-items: center; justify-content: space-between; flex-wrap: wrap; gap: 12px 20px; }
.period-tools { border-block: 1px solid var(--border); padding: 14px 0; }
.period-heading, .period-selection { display: flex; align-items: center; gap: 12px; min-width: 0; }
.period-heading strong { font-size: 13px; font-weight: 600; color: var(--text); }
.period-heading span, .period-selection-label, .period-cutoff { font-size: 11px; color: var(--text-muted); }
.period-heading b { color: var(--text); font-weight: 500; margin-left: 6px; }
.period-selection :deep(.mac-select) { width: 128px; }
.period-selection :deep(.mac-select-trigger) { min-height: 32px; }
.period-generate { min-height: 32px; padding: 5px 12px; font-size: 12px; border: 1px solid var(--border); border-radius: 8px; color: var(--text-muted); background: var(--bg-elevated); white-space: nowrap; cursor: pointer; }
.period-generate:disabled { opacity: .45; cursor: default; }
.period-generate:hover:not(:disabled) { color: var(--text); border-color: var(--accent); }
.period-viewbar { padding-top: 14px; }
.period-modes { display: flex; flex-wrap: wrap; gap: 3px; padding: 3px; border-radius: 9px; background: var(--bg-deep); border: 1px solid var(--border); }
.period-modes button { border: 0; background: transparent; padding: 6px 10px; border-radius: 6px; color: var(--text-muted); font-size: 11px; cursor: pointer; }
.period-modes button[aria-pressed="true"] { background: var(--bg-elevated); color: var(--text); box-shadow: 0 1px 3px #0002; }
.period-modes button:focus-visible, .period-generate:focus-visible { outline: 2px solid var(--accent); outline-offset: 2px; }
.period-cutoff { display: flex; flex-wrap: wrap; gap: 6px; font-variant-numeric: tabular-nums; }
.period-note, .period-error { font-size: 11px; line-height: 1.8; margin: 10px 0 16px; color: var(--text-muted); overflow-wrap: anywhere; }
.period-error { color: var(--up); }
.period-comparison { display: grid; grid-template-columns: minmax(0, 1fr); gap: 24px; min-width: 0; }
.period-comparison > .chart-frame { min-width: 0; }
.period-comparison > :not(:first-child):not(.expanded) { border-top: 1px solid var(--border); padding-top: 20px; }
.period-chart-label { font-size: 10px; color: var(--text-muted); white-space: nowrap; padding-top: 8px; }
@media (max-width: 760px) {
  .period-tools, .period-viewbar { align-items: stretch; gap: 12px; }
  .period-heading { justify-content: space-between; width: 100%; }
  .period-selection { display: grid; grid-template-columns: auto minmax(0, 1fr) auto; gap: 8px; width: 100%; }
  .period-selection :deep(.mac-select) { width: 100%; }
  .period-modes { width: 100%; }
  .period-modes button { flex: 1; padding-inline: 6px; white-space: nowrap; }
  .period-chart-label { display: none; }
}
@media (max-width: 1400px) {
  .period-comparison :deep(.indicator-control) { flex-direction: column; align-items: flex-start; gap: 7px; }
  .period-comparison :deep(.indicator-actions) { width: 100%; min-width: 0; overflow-x: auto; }
  .period-comparison :deep(.indicator-options) { flex: 0 0 auto; }
  .period-comparison :deep(.indicator-heading) { flex-wrap: wrap; }
  .period-comparison :deep(.indicator-control > .indicator-heading) { width: 100%; flex-wrap: nowrap; }
  .period-chart-label { display: none; }
}
</style>
