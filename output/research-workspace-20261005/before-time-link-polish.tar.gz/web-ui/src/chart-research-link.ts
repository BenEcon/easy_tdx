import type { Bar } from './types'

export type TimeWindow = { start: string; end: string }
export const stamp = (value: string) => value.replace('T', ' ').slice(0, 19)
/** Match exchange-local intervals, never ordinal indices across different periods. */
export function barWindow(bar: Bar, category = ''): TimeWindow {
  let start = stamp(bar.datetime)
  const period = category.toUpperCase()
  // Providers may label weekly/monthly candles by their last trading day.
  // Calendar starts are only display coverage; do not invent constituent bars.
  if (period === 'WEEK') {
    const day = new Date(`${start.slice(0, 10)}T00:00:00Z`)
    day.setUTCDate(day.getUTCDate() - (day.getUTCDay() + 6) % 7)
    if (Number.isFinite(day.getTime())) start = `${day.toISOString().slice(0, 10)} 00:00:00`
  } else if (period === 'MONTH') start = `${start.slice(0, 7)}-01 00:00:00`
  return { start, end: stamp(bar.period_end ?? bar.datetime) }
}
export function overlappingBars(bars: Bar[], window: TimeWindow, category = ''): number[] {
  return bars.flatMap((bar, index) => {
    const range = barWindow(bar, category)
    // Adjacent minute bars share an endpoint, but are not the same interval.
    const hit = range.start === window.start || (range.start < window.end && range.end > window.start)
    return hit ? [index] : []
  })
}
export type MarkerCandidate<T> = { value: T; center: number[]; size: number[] }
export function nearestMarkers<T>(items: MarkerCandidate<T>[], x: number, y: number): T[] {
  const hits = items.filter(item => [...item.center, ...item.size, x, y].every(Number.isFinite)
    && Math.abs(x - item.center[0]!) <= Math.max(5, item.size[0]! / 2) + 2
    && Math.abs(y - item.center[1]!) <= Math.max(5, item.size[1]! / 2) + 2)
    .sort((a, b) => Math.hypot(x - a.center[0]!, y - a.center[1]!) - Math.hypot(x - b.center[0]!, y - b.center[1]!))
  const nearest = hits[0]
  if (!nearest) return []
  // Only co-located symbols share a chooser; nearby unrelated points do not steal hits.
  return hits.filter(item => Math.hypot(item.center[0]! - nearest.center[0]!, item.center[1]! - nearest.center[1]!) <= 2).map(item => item.value)
}
