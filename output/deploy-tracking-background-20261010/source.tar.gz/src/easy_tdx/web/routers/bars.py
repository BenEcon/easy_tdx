"""K线 / 分时 / 逐笔成交路由。"""

from __future__ import annotations

from datetime import date
from typing import Any, Literal

import pandas as pd
from fastapi import APIRouter, Depends, HTTPException, Query

from easy_tdx._df import _category_to_minutes
from easy_tdx.web.convert import (
    category_from_str,
    market_from_str,
    market_value_from_str,
    period_times_from_category,
)
from easy_tdx.web.deps import get_client, get_mac_client_optional
from easy_tdx.web.schemas import DataFrameResponse

router = APIRouter(tags=["bars"])

# 规整后保持的列顺序（匹配旧 SecurityBar 输出契约）
_NORMAL_COLS = ["open", "close", "high", "low", "vol", "amount"]


def _df_resp(df: Any) -> DataFrameResponse:
    return DataFrameResponse.from_dataframe(df)


def _is_daily_plus(cat: Any) -> bool:
    """判断 KlineCategory 是否日线及以上周期（datetime 应归一为 date）。

    KlineCategory 的枚举值不按周期长短排序（MIN_1=7、MIN_3=8 均大于 DAY=4），
    不能用整数大小判断"日线及以上"；与 client.py 的 get_security_bars 路径保持
    同一判定源：_CATEGORY_MINUTES 查得到=分钟级，查不到=日线及以上。
    """
    return _category_to_minutes(int(cat)) is None


def _normalize_mac_df(df: pd.DataFrame, daily_plus: bool) -> pd.DataFrame:
    """规整 MacClient.get_stock_kline 的输出以匹配旧 /bars 契约。

    MacClient 返回 ``datetime`` 列（含时分秒）+ ``float_shares`` 列，OHLC 顺序为
    open/high/low/close。旧 /bars（SecurityBar 路径）日线返回 ``date`` 列（仅日期）、
    分钟线返回 ``datetime`` 列，无 float_shares，OHLC 顺序为 open/close/high/low。
    本函数做对齐，保证迁移后调用方输出契约不变。

    Args:
        df: MacClient 返回的 DataFrame（可能为空）。
        daily_plus: True=日线及以上周期（datetime→date），False=分钟线（保留 datetime）。
    """
    if df.empty:
        return df
    out = df.copy()
    if "float_shares" in out.columns:
        out = out.drop(columns=["float_shares"])
    time_col = "date" if daily_plus else "datetime"
    if "datetime" in out.columns:
        if daily_plus:
            # 截断为仅日期（00:00:00），与旧 _merge_bar_datetime 的 date 列语义一致
            out["datetime"] = pd.to_datetime(out["datetime"]).dt.normalize()
        out = out.rename(columns={"datetime": time_col})
    # 重排列顺序：时间列在前，OHLC 顺序 open/close/high/low，再 vol/amount
    cols = [c for c in [time_col, *_NORMAL_COLS] if c in out.columns]
    # 兜底：保留未列出的列（理论上不应有），追加到末尾
    cols += [c for c in out.columns if c not in cols]
    return out[cols]


@router.get("/bars")
async def security_bars(
    market: str = Query(..., description="市场: SZ, SH, BJ"),
    code: str = Query(..., min_length=6, max_length=6),
    category: str = Query(
        "DAY",
        description="K线周期: MIN_1, MIN_5, MIN_15, MIN_30, MIN_60, DAY, WEEK, MONTH, YEAR",
    ),
    start: int = Query(0, ge=0),
    count: int = Query(800, ge=1, le=800),
    bar_time: str = Query(
        "start",
        description="时间戳: native=行情原始收盘标签（研究推荐）；start/end 保留旧客户端偏移契约",
    ),
    adjust: str = Query(
        "QFQ", description="复权: NONE=不复权 / QFQ=前复权(默认) / HFQ=后复权（需 MAC 客户端）"
    ),
    mac_client: Any = Depends(get_mac_client_optional),
    client: Any = Depends(get_client),
) -> dict[str, Any]:
    """获取股票K线数据（MAC 协议，支持复权）。

    优先走 AsyncMacClient.get_stock_kline（支持 NONE/QFQ/HFQ 复权 + QFQ 负价兜底）；
    MAC 主机未连接时仅 NONE 请求允许回退标准行情；复权请求明确失败，不静默改变口径。
    输出契约与旧版一致：日线返回 ``date`` 列，分钟线返回 ``datetime`` 列。
    """
    from easy_tdx.web.market_data import load_equity_frame

    category = category.upper()
    df = await load_equity_frame(
        client, mac_client, market, code, category, start, count, adjust, bar_time=bar_time
    )
    metadata = df.attrs["snapshot_metadata"]
    cat = category_from_str("MIN_60" if category == "MIN_120" else category)
    df = _normalize_mac_df(df, daily_plus=_is_daily_plus(cat))
    return {"data": _df_resp(df).data, "count": len(df), "metadata": metadata}


@router.get("/bars/range")
async def security_bar_range(
    market: Literal["SH", "SZ", "BJ"],
    code: str = Query(pattern=r"^\d{6}$"),
    category: str = "DAY",
    adjust: Literal["QFQ", "HFQ", "NONE"] = "QFQ",
    start_date: date | None = None,
    end_date: date | None = None,
    mac_client: Any = Depends(get_mac_client_optional),
    client: Any = Depends(get_client),
) -> dict[str, Any]:
    """Closed history with cross-page consistency and full-range provenance."""
    from easy_tdx.web.market_range import load_equity_range

    return await load_equity_range(
        client, mac_client, market, code, category, adjust, start_date, end_date
    )


@router.get("/bars/index")
async def index_bars(
    market: str = Query(..., description="市场: SZ, SH"),
    code: str = Query(..., min_length=6, max_length=6),
    category: str = Query("DAY", description="K线周期"),
    start: int = Query(0, ge=0),
    count: int = Query(800, ge=1, le=800),
    bar_time: str = Query(
        "start", description="时间戳: start=bar开始时间(默认) / end=bar结束时间(对齐Tushare)"
    ),
    client: Any = Depends(get_client),
) -> dict[str, Any]:
    """获取指数K线数据。"""
    from easy_tdx.web.market_data import checked_snapshot

    if bar_time not in ("native", "start", "end"):
        raise HTTPException(422, "bar_time 须为 native、start 或 end")
    df = await client.get_index_bars(
        market_from_str(market),
        code,
        category_from_str(category),
        start,
        count,
        bar_time="start" if bar_time == "native" else bar_time,
    )
    snapshot = checked_snapshot(
        _df_resp(df).data,
        category,
        source="TDX_INDEX",
        requested_adjust="NONE",
        actual_adjust="NONE",
        bar_time="end" if bar_time == "native" else bar_time,
    )
    snapshot["metadata"]["instrument"] = {"kind": "index", "market": market, "code": code}
    return snapshot


@router.get("/bars/research")
async def research_bars(
    kind: Literal["index", "board"],
    code: str = Query(pattern=r"^\d{6}$"),
    market: Literal["SH", "SZ"] = "SH",
    board_type: Literal["HY", "HY2", "GN", "FG", "DQ"] = "HY",
    category: Literal[
        "DAY", "WEEK", "MONTH", "YEAR", "MIN_1", "MIN_5", "MIN_15", "MIN_30", "MIN_60", "MIN_120"
    ] = "DAY",
    count: int = Query(600, ge=1, le=800),
    mac_client: Any = Depends(get_mac_client_optional),
    client: Any = Depends(get_client),
) -> dict[str, Any]:
    """Research snapshots retain instrument identity; never apply stock adjustment.

    MAC supports indices with an explicit exchange; the dedicated standard index
    command is a fallback when MAC is absent or returns no bars. Board markets
    come from the selected official catalog, not a stock-code prefix heuristic.
    """
    from easy_tdx.mac.enums import Adjust, Period
    from easy_tdx.web.convert import board_type_from_str
    from easy_tdx.web.market_data import checked_snapshot

    if kind == "index" and category == "MIN_120":
        raise HTTPException(
            422, "指数行情暂不支持 120 分钟，请选择 60 分钟或日线；不会用其他周期替代"
        )
    cat = category_from_str("MIN_60" if category == "MIN_120" else category)
    identity = {"kind": kind, "market": market, "code": code}
    if kind == "index":
        df = pd.DataFrame()
        source = "MAC_INDEX"
        if mac_client is not None:
            period, times = period_times_from_category(cat)
            df = await mac_client.get_stock_kline(
                market_value_from_str(market),
                code,
                period,
                0,
                count,
                times,
                adjust=Adjust.NONE,
                bar_time="start",
            )
            df = _normalize_mac_df(df, daily_plus=_is_daily_plus(cat))
        if df.empty:
            df = await client.get_index_bars(
                market_from_str(market), code, cat, 0, count, bar_time="start"
            )
            source = "TDX_INDEX"
    else:
        if mac_client is None:
            raise HTTPException(503, "板块行情服务暂不可用，请稍后重试")
        catalog = await mac_client.get_board_list(
            board_type=board_type_from_str(board_type), count=5000
        )
        board = next(
            (row for row in catalog.to_dict("records") if str(row.get("code")) == code), None
        )
        if board is None:
            raise HTTPException(404, "所选分类中未找到该板块，请重新选择")
        if board.get("market") is None:
            raise HTTPException(502, "板块目录缺少市场信息，已停止查询以免使用错误行情")
        period, times = period_times_from_category(cat)
        if category == "MIN_120":
            period, times = Period.MINS, 24
        df = await mac_client.get_stock_kline(
            int(board["market"]),
            code,
            period,
            0,
            count,
            times,
            adjust=Adjust.NONE,
            bar_time="start",
        )
        df = _normalize_mac_df(df, daily_plus=_is_daily_plus(cat))
        source = "MAC_BOARD"
        identity.update(
            market=str(board["market"]), board_type=board_type, name=str(board.get("name", code))
        )
    if df.empty:
        raise HTTPException(404, "该标的在所选周期暂无行情，请切换周期或稍后重试")
    snapshot = checked_snapshot(
        _df_resp(df).data,
        category,
        source=source,
        requested_adjust="NONE",
        actual_adjust="NONE",
        bar_time="end",
    )
    snapshot["metadata"]["instrument"] = identity
    return snapshot


@router.get("/minute", response_model=DataFrameResponse)
async def minute_time(
    market: str = Query(..., description="市场: SZ, SH"),
    code: str = Query(..., min_length=6, max_length=6),
    client: Any = Depends(get_client),
) -> DataFrameResponse:
    """获取今日分时数据。"""
    df = await client.get_minute_time_data(market_from_str(market), code)
    return _df_resp(df)


@router.get("/minute/history", response_model=DataFrameResponse)
async def history_minute_time(
    market: str = Query(..., description="市场: SZ, SH"),
    code: str = Query(..., min_length=6, max_length=6),
    date: int = Query(..., description="日期 YYYYMMDD"),
    client: Any = Depends(get_client),
) -> DataFrameResponse:
    """获取历史某日分时数据。"""
    df = await client.get_history_minute_time_data(market_from_str(market), code, date)
    return _df_resp(df)


@router.get("/transaction", response_model=DataFrameResponse)
async def transaction_data(
    market: str = Query(..., description="市场: SZ, SH"),
    code: str = Query(..., min_length=6, max_length=6),
    start: int = Query(0, ge=0),
    count: int = Query(800, ge=1, le=800),
    client: Any = Depends(get_client),
) -> DataFrameResponse:
    """获取当日逐笔成交。"""
    df = await client.get_transaction_data(market_from_str(market), code, start, count)
    return _df_resp(df)


@router.get("/transaction/history", response_model=DataFrameResponse)
async def history_transaction_data(
    market: str = Query(..., description="市场: SZ, SH"),
    code: str = Query(..., min_length=6, max_length=6),
    date: int = Query(..., description="日期 YYYYMMDD"),
    start: int = Query(0, ge=0),
    count: int = Query(800, ge=1, le=800),
    client: Any = Depends(get_client),
) -> DataFrameResponse:
    """获取历史逐笔成交。"""
    df = await client.get_history_transaction_data(
        market_from_str(market), code, date, start, count
    )
    return _df_resp(df)
