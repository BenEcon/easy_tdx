"""Shared valuation and performance for independently funded strategy slots."""

from __future__ import annotations

from typing import Any

import pandas as pd

from easy_tdx.backtest.performance import PerformanceAnalyzer
from easy_tdx.backtest.types import BacktestResult


def combine_equity(
    results: dict[str, BacktestResult], allocations: dict[str, float]
) -> pd.DataFrame:
    columns = ["datetime", "total", "drawdown", "drawdown_pct"]
    series: dict[str, pd.Series] = {}
    for key, result in results.items():
        curve = result.equity_curve
        if curve.empty:
            continue
        raw = curve["datetime"]
        dates = (
            pd.to_datetime(raw.astype(str), format="%Y%m%d")
            if raw.dtype.kind in "iu"
            else pd.to_datetime(raw)
        )
        index = pd.DatetimeIndex(dates)
        if index.hasnans or index.has_duplicates or not index.is_monotonic_increasing:
            raise ValueError("组合成员净值时间缺失、重复或乱序")
        series[key] = pd.Series(curve.total.to_numpy(), index=index)
    if not series:
        return pd.DataFrame(columns=columns)
    aligned = pd.concat(series, axis=1).sort_index().ffill()
    # A slot not started yet still holds its allocated cash. Zero would create
    # fictitious deposits and gains when its first observation arrives.
    for key, cash in allocations.items():
        aligned[key] = aligned[key].fillna(cash) if key in aligned else cash
    total = aligned.sum(axis=1)
    peak = total.cummax()
    drawdown = peak - total
    return pd.DataFrame(
        {
            "datetime": total.index,
            "total": total.to_numpy(),
            "drawdown": drawdown.to_numpy(),
            "drawdown_pct": (drawdown / peak.where(peak != 0, 1)).to_numpy(),
        }
    ).reset_index(drop=True)


def aggregate_performance(
    results: dict[str, BacktestResult], allocations: dict[str, float], curve: pd.DataFrame
) -> tuple[dict[str, float], dict[str, Any]]:
    bases = [result.config.get("performance_basis", {}) for result in results.values()]
    categories = {basis.get("input_category", "DAY") for basis in bases}
    category = next(iter(categories)) if len(categories) == 1 else "DAY"
    source = curve.copy(deep=False)
    # Daily legacy library callers retain the declared legacy convention.
    explicit = any(basis.get("category_source") != "legacy_daily_default" for basis in bases)
    if explicit:
        labels = {result.config.get("bar_time", "end") for result in results.values()}
        source.attrs["snapshot_metadata"] = {
            "category": category,
            "bar_time": next(iter(labels)) if len(labels) == 1 else "end",
        }
    trade_frames = []
    for key, result in results.items():
        if not result.trades.empty:
            frame = result.trades.copy()
            frame["performance_slot"] = key
            trade_frames.append(frame)
    trades = (
        pd.concat(trade_frames, ignore_index=True)
        if trade_frames
        else pd.DataFrame(columns=["direction", "pnl", "rejected"])
    )
    analyzer = PerformanceAnalyzer(curve, trades, source=source)
    metrics = analyzer.compute()
    # FIFO lots cannot be paired across independent securities/strategy slots.
    weighted_days = 0.0
    weight = 0.0
    for result in results.values():
        frame = result.trades
        if not frame.empty and "size" in frame:
            sold = float(frame.loc[(frame.direction == "SELL") & ~frame.rejected, "size"].sum())
            weighted_days += sold * result.performance.get("avg_holding_days", 0.0)
            weight += sold
    metrics["avg_holding_days"] = weighted_days / weight if weight else 0.0
    metrics.update(total_stocks=float(len(results)), total_cash=sum(allocations.values()))
    basis = dict(analyzer.basis)
    basis["valuation_policy"] = "initial_cash_then_last_observed_equity"
    if len(categories) > 1:
        basis["input_category"] = "MIXED"
        basis["unavailable_reason"] = (
            "成员周期不同，未将不同频率的估值并集视为等间隔收益；总收益与回撤仍保留"
        )
        for name in ("annual_return", "sharpe", "sharpe_ratio", "sortino", "calmar", "volatility"):
            metrics[name] = float("nan")
    return metrics, basis
