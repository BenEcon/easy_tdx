"""Versioned mainland cash-equity calendar; unknown years never imply holidays known.

Annual exchange notices (not civil-service make-up working days):
2024 https://www.sse.com.cn/disclosure/announcement/general/c/c_20231226_5733939.shtml
2025 https://www.sse.com.cn/disclosure/announcement/general/c/c_20241223_10767108.shtml
2026 https://www.sse.com.cn/disclosure/announcement/general/c/c_20251222_10802507.shtml
"""

from datetime import date, timedelta

VERSION = "sse-cash-2024-2026-v1"
HOLIDAY_RANGES = {
    2024: [
        ("01-01", "01-01"),
        ("02-09", "02-17"),
        ("04-04", "04-06"),
        ("05-01", "05-05"),
        ("06-10", "06-10"),
        ("09-15", "09-17"),
        ("10-01", "10-07"),
    ],
    2025: [
        ("01-01", "01-01"),
        ("01-28", "02-04"),
        ("04-04", "04-06"),
        ("05-01", "05-05"),
        ("05-31", "06-02"),
        ("10-01", "10-08"),
    ],
    2026: [
        ("01-01", "01-03"),
        ("02-15", "02-23"),
        ("04-04", "04-06"),
        ("05-01", "05-05"),
        ("06-19", "06-21"),
        ("09-25", "09-27"),
        ("10-01", "10-07"),
    ],
}


def is_session(day: date) -> bool | None:
    if day.year not in HOLIDAY_RANGES:
        return None
    return day.weekday() < 5 and not any(
        date.fromisoformat(f"{day.year}-{start}") <= day <= date.fromisoformat(f"{day.year}-{end}")
        for start, end in HOLIDAY_RANGES[day.year]
    )


def last_session(start: date, end: date) -> date | None:
    """None means unknown coverage OR no session; never roll into another period."""
    if any(year not in HOLIDAY_RANGES for year in range(start.year, end.year + 1)):
        return None
    day = end
    while day >= start:
        if is_session(day):
            return day
        day -= timedelta(days=1)
    return None


def missing_sessions(start: date, end: date, observed: set[date]) -> list[str]:
    # Missing does not imply suspension or a feed outage: those require separate evidence.
    out = []
    day = start
    while day <= end:
        if is_session(day) is True and day not in observed:
            out.append(day.isoformat())
        day += timedelta(days=1)
    return out
