import test from 'node:test'
import assert from 'node:assert/strict'
import {factorValue,sortedFactorRows,factorSearchKey} from '../src/factor-research.ts'
test('factor glossary accepts standard abbreviations with spaces or underscores',()=>{
  for(const term of ['RankIC','Rank IC','rank_ic','rank-ic'])assert.equal(factorSearchKey(term),'rankic')
  assert.equal(factorSearchKey(' 秩相关 '),'秩相关')
})
test('factor missing values never become valid zero',()=>{
  for(const value of [null,undefined,NaN,Infinity,'0','',false])assert.equal(factorValue(value),'—')
  assert.equal(factorValue(0),'0.00');assert.equal(factorValue(.0345,true),'3.45%')
})
test('factor ranking is stable, non-mutating and missing-last in both directions',()=>{
  const rows=[{code:'c',v:null},{code:'b',v:2},{code:'a',v:2},{code:'d',v:0}]
  const original=structuredClone(rows)
  assert.deepEqual(sortedFactorRows(rows,'v',-1).map(r=>r.code),['a','b','d','c'])
  assert.deepEqual(sortedFactorRows(rows,'v',1).map(r=>r.code),['d','a','b','c'])
  assert.deepEqual(rows,original)
})
