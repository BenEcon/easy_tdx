<script setup lang="ts">
import {ref,onMounted,onBeforeUnmount,watch} from 'vue'
import echarts from '../echarts-setup'
import {useChartResize} from '../chart-resize'
const props=defineProps<{labels:string[];series:Array<{name:string;values:Array<number|null>}>;bar?:boolean;percent?:boolean}>()
const el=ref<HTMLElement>()
let chart:echarts.ECharts|null=null
function render(){
  if(!el.value)return
  chart??=echarts.init(el.value,'dark')
  chart.setOption({animation:false,tooltip:{trigger:'axis',renderMode:'richText',valueFormatter:(v:unknown)=>typeof v==='number'?`${v.toFixed(2)}${props.percent?'%':''}`:'—'},legend:{top:4},grid:{left:50,right:20,top:45,bottom:60},xAxis:{type:'category',data:props.labels,axisLabel:{hideOverlap:true}},yAxis:{type:'value',scale:true,axisLabel:{formatter:(v:number)=>`${v.toFixed(2)}${props.percent?'%':''}`}},dataZoom:props.bar?[]:[{type:'inside'},{type:'slider',height:16,bottom:8}],series:props.series.map((s,i)=>({name:s.name,type:props.bar?'bar':'line',data:s.values.map(v=>v===null?null:v*(props.percent?100:1)),connectNulls:false,showSymbol:false,barMaxWidth:45,lineStyle:{width:1.5},itemStyle:{color:['#66afff','#baa4ed','#6ecbb4','#d6b473'][i%4]}}))},true)
}
onMounted(render);watch(()=>[props.labels,props.series,props.bar,props.percent],render,{deep:true});useChartResize(el,()=>chart?.resize());onBeforeUnmount(()=>chart?.dispose())
</script>
<template><div ref="el" class="factor-chart" role="img" aria-label="因子检验图；对应数值见下方明细表" /></template>
<style scoped>.factor-chart{width:100%;height:310px;min-width:0;flex:1}:fullscreen .factor-chart{height:70vh}.fallback-expanded .factor-chart{height:70vh}</style>
