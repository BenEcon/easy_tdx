import type {MarketDataMetadata} from './market-data-contract'

export function factorSearchKey(value:string):string {
  return value.toLowerCase().replace(/[\s_-]+/g,'')
}

export interface FactorDay {date:string;n:number;ic:number|null;rank_ic:number|null;rolling_rank_ic:number|null;layers:Array<number|null>;reason:string|null}
export interface FactorReport {name:string;coverage:number;observations:number;ic_mean:number|null;rank_ic_mean:number|null;rank_ic_ir:number|null;positive_rate:number|null;layer_means:Array<number|null>;spread:number|null;layer_dates:number;diagnostics:Record<string,number>;daily:FactorDay[]}
export interface FactorEvaluation {version:string;settings:{factors:string[];horizon:number;groups:number;preprocess:string};reports:FactorReport[];errors:Record<string,string>;latest:Array<Record<string,string|number|null>>;redundancy:Array<{left:string;right:string;correlation:number|null;dates:number}>;input_fingerprint:string;start:string;end:string;date_count:number;assets:number;missing_bars:number;trade_eligible:false;limitations:string[];adjust:string;provenance:Array<{code:string;count:number;metadata:MarketDataMetadata}>}

export function factorValue(value:unknown,percent=false):string {
  if(typeof value!=='number'||!Number.isFinite(value))return '—'
  return `${(value*(percent?100:1)).toFixed(2)}${percent?'%':''}`
}

export function sortedFactorRows(rows:FactorEvaluation['latest'],name:string,direction:1|-1) {
  return [...rows].sort((a,b)=>{
    const av=a[name],bv=b[name]
    const va=typeof av==='number'&&Number.isFinite(av),vb=typeof bv==='number'&&Number.isFinite(bv)
    if(!va)return vb?1:String(a.code).localeCompare(String(b.code))
    if(!vb)return -1
    return direction*(av-bv)||String(a.code).localeCompare(String(b.code))
  })
}
