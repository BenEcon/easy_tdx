"""量化研究 Web 路由：因子计算、组合权重与风险分析。"""

from __future__ import annotations

import hashlib
import json
from typing import Any, Literal

import numpy as np
import pandas as pd
from fastapi import APIRouter, Depends
from pydantic import BaseModel, Field, model_validator

from easy_tdx.web.adjusted_bars import fetch_adjusted_bars
from easy_tdx.web.deps import get_client, get_mac_client_optional
from easy_tdx.web.market_data import closed_frame
from easy_tdx.web.schemas import DataFrameResponse, DictResponse, StockIdentifier

router = APIRouter(tags=["research"])


class FactorComputeRequest(BaseModel):
    market: str = Field(..., pattern=r"^(SZ|SH|BJ)$")
    code: str = Field(..., min_length=6, max_length=6)
    category: Literal["DAY", "WEEK", "MONTH", "MIN_1", "MIN_5", "MIN_15", "MIN_30", "MIN_60"] = (
        "DAY"
    )
    count: int = Field(default=300, ge=60, le=800)
    factors: list[str] = Field(..., min_length=1, max_length=12)
    factor_parameters: dict[str, dict[str, Any]] = Field(default_factory=dict)
    adjust: Literal["NONE", "QFQ", "HFQ"] = "QFQ"

    @model_validator(mode="after")
    def validate_factors(self) -> FactorComputeRequest:
        from easy_tdx.factor import get_factor
        from easy_tdx.factor.catalog import canonical_factor_name, describe_factor
        from easy_tdx.factor.configuration import configured_selection

        configured_selection(self.factors, self.factor_parameters)

        if len({canonical_factor_name(n) for n in self.factors}) != len(self.factors):
            raise ValueError("不能重复选择同一因子或其兼容别名")
        for name in self.factors:
            definition = describe_factor(get_factor(name))
            if self.category not in definition["supported_categories"]:
                raise ValueError(f"{name} 不支持 {self.category}；未静默转换周期")
        return self


class FactorEvaluationRequest(BaseModel):
    stocks: list[StockIdentifier] = Field(..., min_length=5, max_length=20)
    factors: list[str] = Field(..., min_length=1, max_length=4)
    factor_parameters: dict[str, dict[str, Any]] = Field(default_factory=dict)
    count: int = Field(default=300, ge=80, le=800)
    horizon: Literal[1, 5, 10, 20] = 5
    groups: Literal[3, 5] = 5
    preprocess: Literal["raw", "mad_zscore"] = "raw"
    adjust: Literal["NONE", "QFQ", "HFQ"] = "QFQ"

    @model_validator(mode="after")
    def validate_selection(self) -> FactorEvaluationRequest:
        from easy_tdx.factor import get_factor
        from easy_tdx.factor.catalog import canonical_factor_name, describe_factor
        from easy_tdx.factor.configuration import configured_selection

        configured_selection(self.factors, self.factor_parameters)

        if len({(s.market, s.code) for s in self.stocks}) != len(self.stocks):
            raise ValueError("检验标的不能重复")
        if len({canonical_factor_name(n) for n in self.factors}) != len(self.factors):
            raise ValueError("检验因子不能重复")
        for name in self.factors:
            definition = describe_factor(get_factor(name))
            from easy_tdx.factor.catalog import availability_reason

            reason = availability_reason(definition, self.adjust, evaluation=True)
            if reason:
                raise ValueError(reason)
        return self


class PortfolioRiskRequest(BaseModel):
    stocks: list[StockIdentifier] = Field(..., min_length=2, max_length=20)
    method: Literal["equal", "factor_weighted", "risk_parity", "mean_variance"] = "risk_parity"
    category: Literal["DAY"] = "DAY"
    count: int = Field(default=300, ge=60, le=800)
    adjust: Literal["NONE", "QFQ", "HFQ"] = "QFQ"

    @model_validator(mode="after")
    def unique_assets(self) -> PortfolioRiskRequest:
        if len({s.code for s in self.stocks}) != len(self.stocks):
            raise ValueError("组合标的代码不得重复；当前风险模型按股票代码标识资产")
        return self


def _json_safe_frame(df: pd.DataFrame) -> pd.DataFrame:
    clean = df.replace([np.inf, -np.inf], np.nan)
    return clean.astype(object).where(pd.notna(clean), None)


@router.get("/research/factors")
async def factor_list() -> list[dict[str, Any]]:
    """列出全部内置量化因子及其输入字段。"""
    from easy_tdx.factor import list_factors

    return list_factors()


async def _factor_fields(
    df: pd.DataFrame,
    factors: list[str],
    client: Any,
    mac_client: Any,
    market: str,
    code: str,
    category: str,
    count: int,
    adjust: str,
) -> pd.DataFrame:
    """Internal data qualification, not another user query or a chart mutation."""
    from easy_tdx.factor import get_factor
    from easy_tdx.factor.data import qualify_factor_fields

    needed = set().union(*(set(get_factor(name).inputs) for name in factors))
    qualified_fields = {"volume", "vwap"}.intersection(needed)
    if not qualified_fields:
        return df
    out = df.copy()
    out.attrs.pop("factor_data_contract", None)
    out.attrs.pop("factor_input_errors", None)
    # Never trust a preexisting canonical field from an unqualified feed.
    out = out.drop(columns=["volume", "vwap"], errors="ignore")
    errors: dict[str, str] = {}
    if "vwap" in needed and adjust != "NONE":
        errors["vwap"] = "VWAP 当前仅支持不复权；缺少复权成交价变换依据"
        if "volume" not in needed:
            out.attrs["factor_input_errors"] = errors
            return out
    try:
        raw = (
            out
            if adjust == "NONE"
            else closed_frame(
                await fetch_adjusted_bars(
                    client, mac_client, market, code, category, 0, count, "NONE"
                )
            )
        )
        out = qualify_factor_fields(out, raw, need_vwap="vwap" in needed and adjust == "NONE")
        out.attrs["factor_data_contract"]["instrument"] = f"{market}:{code}"
    except Exception as exc:
        # Field-specific failures must not suppress unrelated price factors.
        reason = getattr(exc, "detail", None) or str(exc) or type(exc).__name__
        errors.update(
            {field: f"量额核验失败：{reason}" for field in qualified_fields if field not in errors}
        )
    if errors:
        out.attrs["factor_input_errors"] = errors
    return out


@router.post("/research/factors/evaluate", response_model=DictResponse)
async def factor_evaluate(
    req: FactorEvaluationRequest,
    client: Any = Depends(get_client),
    mac_client: Any | None = Depends(get_mac_client_optional),
) -> DictResponse:
    from easy_tdx.factor.research import cross_section_report
    from easy_tdx.web.resource_admission import run_compute

    frames = {}
    provenance = []
    for stock in req.stocks:
        df = closed_frame(
            await fetch_adjusted_bars(
                client, mac_client, stock.market, stock.code, "DAY", 0, req.count, req.adjust
            )
        )
        symbol = f"{stock.market}:{stock.code}"
        if df.empty or len(df) < 60:
            raise ValueError(f"{symbol} 已收盘日线不足 60 根；未静默跳过该标的")
        metadata = df.attrs.get("snapshot_metadata")
        if not isinstance(metadata, dict) or metadata.get("actual_adjust") != req.adjust:
            raise ValueError(f"{symbol} 复权来源不一致或缺失；已停止检验")
        quality = metadata.get("quality", {})
        if isinstance(quality, dict) and quality.get("status") == "error":
            raise ValueError(f"{symbol} 行情质量检查失败；已停止检验")
        df = await _factor_fields(
            df,
            req.factors,
            client,
            mac_client,
            stock.market,
            stock.code,
            "DAY",
            req.count,
            req.adjust,
        )
        frames[symbol] = df
        provenance.append(
            {
                "code": symbol,
                "count": len(df),
                "metadata": df.attrs.get("snapshot_metadata"),
                "factor_data_contract": df.attrs.get("factor_data_contract"),
                "factor_input_errors": df.attrs.get("factor_input_errors", {}),
            }
        )
    result = await run_compute(
        lambda: cross_section_report(
            frames,
            req.factors,
            req.horizon,
            req.groups,
            req.preprocess,
            factor_parameters=req.factor_parameters,
        )
    )
    result["settings"].update(
        category="DAY",
        count=req.count,
        adjust=req.adjust,
        stocks=[stock.model_dump() for stock in req.stocks],
    )
    return DictResponse(data={**result, "provenance": provenance, "adjust": req.adjust})


@router.post("/research/factors/compute", response_model=DictResponse)
async def factor_compute(
    req: FactorComputeRequest,
    client: Any = Depends(get_client),
    mac_client: Any | None = Depends(get_mac_client_optional),
) -> DictResponse:
    """获取单股行情并计算一个或多个内置因子。"""
    from easy_tdx.web.resource_admission import run_compute

    df = await fetch_adjusted_bars(
        client, mac_client, req.market, req.code, req.category, 0, req.count, req.adjust
    )
    df = closed_frame(df)
    if "date" in df.columns and "datetime" not in df.columns:
        df = df.rename(columns={"date": "datetime"})
    if df.empty:
        return DictResponse(
            data={
                "rows": [],
                "count": 0,
                "errors": {},
                "metadata": df.attrs.get("snapshot_metadata"),
            }
        )

    df = await _factor_fields(
        df,
        req.factors,
        client,
        mac_client,
        req.market,
        req.code,
        req.category,
        req.count,
        req.adjust,
    )

    return await run_compute(lambda: _factor_result(req, df))


def _factor_result(req: FactorComputeRequest, df: pd.DataFrame) -> DictResponse:
    from easy_tdx.factor import FactorEngine

    engine = FactorEngine()
    result = df.copy()
    errors: dict[str, str] = {}
    computed: list[str] = []
    definitions: dict[str, Any] = {}
    diagnostics: dict[str, Any] = {}
    for factor_name in req.factors:
        try:
            from easy_tdx.factor import get_factor
            from easy_tdx.factor.catalog import availability_reason, describe_factor
            from easy_tdx.factor.configuration import configure_factor

            parameters = req.factor_parameters.get(factor_name)
            definition = describe_factor(get_factor(factor_name), parameters)
            definitions[factor_name] = definition
            reason = availability_reason(definition, req.adjust)
            if reason:
                raise ValueError(reason)
            input_errors = df.attrs.get("factor_input_errors", {})
            for field in definition["inputs"]:
                if field in input_errors:
                    raise ValueError(input_errors[field])
            result = engine.compute_single(result, [configure_factor(factor_name, parameters)])
            computed.append(factor_name)
            finite = np.isfinite(pd.to_numeric(result[factor_name], errors="coerce"))
            valid_count = int(finite.sum())
            diagnostics[factor_name] = {
                "valid_count": valid_count,
                "missing_count": len(df) - valid_count,
                "coverage": valid_count / len(df) if len(df) else 0,
                "status": "available" if valid_count else "no_valid_values",
                "reason": ""
                if valid_count
                else "预热不足、缺失或零分母导致没有有效值；未以 0 替代",
            }
        except Exception as exc:
            errors[factor_name] = str(exc)

    requested_columns = [
        "datetime",
        "open",
        "high",
        "low",
        "close",
        "vol",
        "amount",
        *computed,
    ]
    keep = [column for column in requested_columns if column in result.columns]
    output = _json_safe_frame(result[keep].reset_index(drop=True))
    settings = req.model_dump()
    fingerprint = hashlib.sha256(pd.util.hash_pandas_object(df, index=True).values.tobytes())
    fingerprint.update(
        json.dumps({"settings": settings, "definitions": definitions}, sort_keys=True).encode()
    )
    fingerprint.update(json.dumps(df.attrs.get("factor_data_contract"), sort_keys=True).encode())
    return DictResponse(
        data={
            "rows": DataFrameResponse.from_dataframe(output).data,
            "count": len(output),
            "computed": computed,
            "errors": errors,
            "metadata": df.attrs.get("snapshot_metadata"),
            "factor_data_contract": df.attrs.get("factor_data_contract"),
            "factor_input_errors": df.attrs.get("factor_input_errors", {}),
            "input_count": len(df),
            "settings": settings,
            "factor_definitions": definitions,
            "diagnostics": diagnostics,
            "input_fingerprint": fingerprint.hexdigest(),
            "output_truncated": False,
        }
    )


@router.post("/research/portfolio-risk", response_model=DictResponse)
async def portfolio_risk(
    req: PortfolioRiskRequest,
    client: Any = Depends(get_client),
    mac_client: Any | None = Depends(get_mac_client_optional),
) -> DictResponse:
    """基于在线日线计算组合权重、相关性、年化波动与风险贡献。"""
    from easy_tdx.web.resource_admission import run_compute

    series: list[pd.Series] = []
    asset_rows: list[dict[str, Any]] = []
    provenance: list[dict[str, Any]] = []
    for stock in req.stocks:
        df = await fetch_adjusted_bars(
            client,
            mac_client,
            stock.market,
            stock.code,
            req.category,
            0,
            req.count,
            req.adjust,
        )
        df = closed_frame(df)
        if df.empty or "close" not in df.columns:
            raise ValueError(f"{stock.market}:{stock.code} 无有效收盘行情；未跳过该资产")
        provenance.append(
            {
                "market": stock.market,
                "code": stock.code,
                "count": len(df),
                "metadata": df.attrs.get("snapshot_metadata"),
            }
        )
        time_col = "datetime" if "datetime" in df.columns else "date"
        close = pd.Series(
            pd.to_numeric(df["close"], errors="coerce").to_numpy(),
            index=pd.to_datetime(df[time_col]),
            name=stock.code,
        ).sort_index()
        series.append(close)

    return await run_compute(lambda: _risk_result(req, series, asset_rows, provenance))


def _risk_result(
    req: PortfolioRiskRequest,
    series: list[pd.Series],
    asset_rows: list[dict[str, Any]],
    provenance: list[dict[str, Any]],
) -> DictResponse:
    from easy_tdx.portfolio import RiskModel, get_optimizer

    # Align price observations before computing returns, so missing observations
    # never become zero returns or mismatched holding-period returns across assets.
    prices = pd.concat(series, axis=1).sort_index()
    raw_returns = prices.pct_change(fill_method=None).replace([np.inf, -np.inf], np.nan)
    from datetime import timedelta

    from easy_tdx.web.trading_calendar import missing_sessions

    # If every asset lacks a date, outer alignment alone cannot reveal the gap.
    # A multi-session return must not be annualized as one daily observation.
    calendar_gap_returns = []
    for previous, current in zip(prices.index, prices.index[1:]):
        if missing_sessions(
            previous.date() + timedelta(days=1), current.date() - timedelta(days=1), set()
        ):
            raw_returns.loc[current] = np.nan
            calendar_gap_returns.append(str(current))
    returns = raw_returns.dropna(how="any")
    if len(returns) < 2:
        raise ValueError("共同有效日收益不足 2 条，不能估计组合风险；未用零收益填充缺失行情")
    for stock in req.stocks:
        ret = returns[stock.code]
        annual_return = float(ret.mean(skipna=True) * 252)
        volatility = float(ret.std(skipna=True) * np.sqrt(252))
        asset_rows.append(
            {
                "code": stock.code,
                "market": stock.market,
                "annual_return": annual_return,
                "volatility": volatility,
                "score": annual_return / volatility if volatility > 0 else 0.0,
            }
        )

    scores = pd.DataFrame(asset_rows)
    weights = get_optimizer(req.method).optimize(scores, n_stocks=len(scores))
    risk_model = RiskModel()
    covariance = risk_model.estimate_covariance(returns)
    risk = risk_model.portfolio_risk(weights, covariance)

    codes = [c for c in weights if c in covariance.columns]
    if codes:
        w = np.array([weights[c] for c in codes])
        cov = covariance.loc[codes, codes].to_numpy()
        contribution = np.abs(w * (cov @ w))
        contribution = contribution / contribution.sum() if contribution.sum() > 0 else contribution
        contribution_map = {code: float(contribution[i]) for i, code in enumerate(codes)}
    else:
        contribution_map = {}
    for row in asset_rows:
        row["weight"] = float(weights.get(str(row["code"]), 0.0))
        row["risk_contribution"] = contribution_map.get(str(row["code"]), 0.0)

    correlation = returns.corr().round(4)
    correlation.index.name = "code"
    correlation_rows = DataFrameResponse.from_dataframe(correlation.reset_index()).data
    return DictResponse(
        data={
            "weights": weights,
            "risk": risk,
            "assets": asset_rows,
            "correlation": correlation_rows,
            "observations": len(returns),
            "method": req.method,
            "provenance": provenance,
            "alignment": {
                "policy": "common_observed_daily_returns_no_fill",
                "excluded_observations": len(raw_returns) - len(returns),
                "start": str(returns.index[0]),
                "end": str(returns.index[-1]),
                "annualization": 252,
                "calendar_gap_returns": calendar_gap_returns,
                "note": "仅使用共同有效日收益，不补零；年化按 252 个交易日，非未来收益预测。",
            },
        }
    )
