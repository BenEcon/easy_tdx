import test from 'node:test'
import assert from 'node:assert/strict'
import {factorChartOptions} from '../src/factor-chart.ts'

test('correlation uses its mathematical range; raw factors keep their own scale',()=>{
  const series=[{name:'秩相关',values:[1,null,1]}]
  const bounded=factorChartOptions(['a','b','c'],series,{correlation:true})
  assert.equal(bounded.yAxis.min,-1);assert.equal(bounded.yAxis.max,1)
  assert.equal(bounded.yAxis.scale,false)
  assert.equal(factorChartOptions([],series).yAxis.min,undefined)
})
test('tiny values remain visible and tooltip raw precision is not rounded',()=>{
  const tiny=0.000000123456789
  const auto=factorChartOptions([],[])
  assert.equal(auto.tooltip.valueFormatter(tiny),'1.23e-7')
  assert.equal(auto.yAxis.axisLabel.formatter(tiny),'1.23e-7')
  const raw=factorChartOptions([],[],{precision:'raw'})
  assert.equal(raw.tooltip.valueFormatter(tiny),String(tiny))
  for(const value of [NaN,Infinity,null,undefined])assert.equal(raw.tooltip.valueFormatter(value),'—')
})
test('percentage is presentation only, gaps and source values are preserved',()=>{
  const series=[{name:'分层收益',values:[0.00123456789,null,-0.01]}]
  const before=structuredClone(series)
  const opt=factorChartOptions(['a','b','c'],series,{percent:true,bar:true,precision:'raw'})
  assert.deepEqual(opt.series[0].data,series[0].values)
  assert.equal(opt.tooltip.valueFormatter(series[0].values[0]),`${series[0].values[0]*100}%`)
  assert.equal(opt.series[0].connectNulls,false)
  assert.deepEqual(opt.dataZoom,[])
  assert.deepEqual(series,before)
})
