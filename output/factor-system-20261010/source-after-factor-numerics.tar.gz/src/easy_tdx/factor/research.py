"""Bounded retrospective cross-sectional diagnostics, not executable returns."""

from __future__ import annotations

import hashlib
import json
from typing import Any

import numpy as np
import pandas as pd

from easy_tdx.computation import computation_checkpoint
from easy_tdx.factor.catalog import describe_factor
from easy_tdx.factor.statistics import (
    NUMERIC_POLICY,
    STATISTICS_VERSION,
    coalesced,
    distinct_count,
    indistinguishable,
    mad_zscore,
    mean,
    stable_correlation,
)


def number(value: Any) -> float | None:
    return float(value) if pd.notna(value) and np.isfinite(value) else None


def correlation(x: pd.Series, y: pd.Series, *, rank: bool = False) -> float | None:
    return stable_correlation(x, y, rank=rank)


def prepare_frame(frame: pd.DataFrame) -> pd.DataFrame:
    df = frame.copy()
    time_key = "datetime" if "datetime" in df else "date"
    dates = pd.to_datetime(df[time_key], errors="raise")
    if getattr(dates.dt, "tz", None) is not None:
        dates = dates.dt.tz_convert("Asia/Shanghai").dt.tz_localize(None)
    df.index = pd.DatetimeIndex(dates.dt.normalize())
    if df.index.has_duplicates or not df.index.is_monotonic_increasing:
        raise ValueError("日线日期重复或未按时间递增；已停止因子检验")
    close = pd.to_numeric(df["close"], errors="raise")
    if not np.isfinite(close).all() or (close <= 0).any():
        raise ValueError("收盘价缺失、非正或无效；已停止因子检验")
    return df


def cross_section_report(
    data: dict[str, pd.DataFrame],
    factors: list[str],
    horizon: int,
    groups: int,
    preprocess: str = "raw",
    *,
    factor_parameters: dict[str, dict[str, Any]] | None = None,
) -> dict[str, Any]:
    """No imputation, no tie splitting, no current membership as historical PIT."""
    if len(data) < 5 or any(frame.empty for frame in data.values()):
        raise ValueError("至少需要 5 只具有行情的标的")
    # Validate provided configurations before expensive work, keeping legacy
    # unknown-factor per-result diagnostics when no configuration was supplied.
    if factor_parameters:
        from easy_tdx.factor.configuration import configured_selection

        configured_selection(factors, factor_parameters)
    frames = {symbol: prepare_frame(frame) for symbol, frame in data.items()}
    closes = pd.concat(
        {symbol: frame["close"] for symbol, frame in frames.items()}, axis=1
    ).sort_index()
    dates = closes.index
    # A label requires the entire intervening observed window, including endpoints.
    complete = closes.notna().rolling(horizon + 1).sum().shift(-horizon).eq(horizon + 1)
    returns = (
        (closes.shift(-horizon) / closes - 1).where(complete).replace([np.inf, -np.inf], np.nan)
    )
    matrices: dict[str, pd.DataFrame] = {}
    errors: dict[str, str] = {}
    reports: list[dict[str, Any]] = []
    definitions: dict[str, Any] = {}
    for name in factors:
        computation_checkpoint()
        try:
            from easy_tdx.factor.configuration import configure_factor

            parameters = (factor_parameters or {}).get(name)
            factor = configure_factor(name, parameters)
            definitions[name] = describe_factor(type(factor), parameters)
            parts = {}
            for symbol, frame in frames.items():
                if definitions[name].get("status") == "conditional":
                    from easy_tdx.factor.catalog import availability_reason

                    actual_adjust = frame.attrs.get("snapshot_metadata", {}).get("actual_adjust")
                    adjustment_error = availability_reason(
                        definitions[name], actual_adjust, evaluation=True
                    )
                    if adjustment_error:
                        raise ValueError(f"{symbol} {adjustment_error}")
                for field in factor.inputs:
                    reason = frame.attrs.get("factor_input_errors", {}).get(field)
                    if reason:
                        raise ValueError(f"{symbol} {reason}")
                missing = set(factor.inputs) - set(frame.columns)
                if missing:
                    raise ValueError(f"{symbol} 缺少字段：{', '.join(sorted(missing))}")
                values = factor.compute(frame)
                if not isinstance(values, pd.Series) or not values.index.equals(frame.index):
                    raise ValueError(f"{name} 输出索引与 {symbol} 输入不一致")
                parts[symbol] = values.replace([np.inf, -np.inf], np.nan)
            values = pd.concat(parts, axis=1).reindex(dates)
        except Exception as exc:
            errors[name] = str(exc)
            continue
        raw_coverage = int(values.notna().sum().sum())
        preprocessing_constant = {}
        if preprocess == "mad_zscore":
            preprocessing_constant = {date: distinct_count(values.loc[date]) == 1 for date in dates}
            values = values.apply(mad_zscore, axis=1)
        matrices[name] = values
        rows: list[dict[str, Any]] = []
        reasons: dict[str, int] = {}
        for date in dates:
            computation_checkpoint()
            pair = pd.concat(
                [values.loc[date].rename("factor"), returns.loc[date].rename("return")], axis=1
            ).dropna()
            reason = None
            ic = rank_ic = None
            layer_values: list[float | None] = [None] * groups
            if preprocessing_constant.get(date):
                reason = "原始因子截面为常数或近常数，未标准化放大浮点噪声"
            elif len(pair) < max(5, groups):
                reason = "有效标的不足（含预热、缺失或远期窗口未完成）"
            else:
                ic = stable_correlation(pair["factor"], pair["return"], y_floor=1.0)
                rank_ic = stable_correlation(pair["factor"], pair["return"], rank=True, y_floor=1.0)
                grouping = coalesced(pair["factor"])
                if grouping.nunique() < 2:
                    reason = "因子为常数或近常数，相关系数及分层未定义"
                elif grouping.nunique() < groups:
                    reason = "因子取值过少，不能完整分层"
                else:
                    bins = pd.qcut(
                        grouping.rank(method="average"), groups, labels=False, duplicates="drop"
                    )
                    if bins.nunique() != groups:
                        reason = "分位边界重复，未强拆相同因子值"
                    else:
                        layer_values = [
                            number(mean(pair.loc[bins == q, "return"].to_numpy()))
                            for q in range(groups)
                        ]
                if rank_ic is None and grouping.nunique() >= 2:
                    return_reason = "远期收益为常数或近常数，相关系数未定义"
                    if all(value is not None for value in layer_values):
                        return_reason += "；分层均值仅作描述"
                    reason = f"{reason}；{return_reason}" if reason else return_reason
            if reason:
                reasons[reason] = reasons.get(reason, 0) + 1
            rows.append(
                {
                    "date": date.strftime("%Y-%m-%d"),
                    "n": len(pair),
                    "ic": ic,
                    "rank_ic": rank_ic,
                    "layers": layer_values,
                    "layer_spread": (
                        None
                        if layer_values[0] is None or layer_values[-1] is None
                        else 0.0
                        if indistinguishable(layer_values[0], layer_values[-1], floor=1.0)
                        else layer_values[-1] - layer_values[0]
                    ),
                    "reason": reason,
                }
            )
        ranked = pd.Series([row["rank_ic"] for row in rows], dtype=float)
        valid = ranked.dropna()
        rolling = ranked.rolling(20, min_periods=20).mean()
        for row, value in zip(rows, rolling, strict=True):
            row["rolling_rank_ic"] = number(value)
        std = valid.std() if len(valid) > 1 else np.nan
        layer_frame = pd.DataFrame([row["layers"] for row in rows], dtype=float)
        layer_means = [number(value) for value in layer_frame.mean()]
        spread = pd.Series([row["layer_spread"] for row in rows], dtype=float)
        reports.append(
            {
                "name": name,
                "coverage": raw_coverage / max(1, closes.size),
                "observations": len(valid),
                "ic_mean": number(pd.Series([row["ic"] for row in rows], dtype=float).mean()),
                "rank_ic_mean": number(valid.mean()),
                "rank_ic_ir": number(valid.mean() / std)
                if std > 0 and distinct_count(valid, floor=1.0) > 1
                else None,
                "positive_rate": number((valid > 0).mean()) if len(valid) else None,
                "layer_means": layer_means,
                "spread": number(spread.mean()),
                "layer_dates": int(spread.notna().sum()),
                "diagnostics": reasons,
                "daily": rows,
            }
        )
    redundancy = []
    for left in matrices:
        for right in matrices:
            observations = [
                correlation(matrices[left].loc[day], matrices[right].loc[day], rank=True)
                for day in dates
            ]
            sample = pd.Series(observations, dtype=float).dropna()
            redundancy.append(
                {
                    "left": left,
                    "right": right,
                    "correlation": number(sample.mean()),
                    "dates": len(sample),
                }
            )
    latest = [
        {
            "code": code,
            "date": dates[-1].strftime("%Y-%m-%d"),
            **{name: number(matrix.loc[dates[-1], code]) for name, matrix in matrices.items()},
        }
        for code in closes.columns
    ]
    fingerprint = hashlib.sha256()
    for code, frame in frames.items():
        fingerprint.update(code.encode())
        fingerprint.update(pd.util.hash_pandas_object(frame, index=True).values.tobytes())
        fingerprint.update(
            json.dumps(frame.attrs.get("factor_data_contract"), sort_keys=True).encode()
        )
    settings = {
        "factors": factors,
        "horizon": horizon,
        "groups": groups,
        "preprocess": preprocess,
        "factor_parameters": factor_parameters or {},
    }
    fingerprint.update(json.dumps(settings, sort_keys=True).encode())
    fingerprint.update(json.dumps(definitions, sort_keys=True).encode())
    fingerprint.update(json.dumps(NUMERIC_POLICY, sort_keys=True).encode())
    return {
        "version": "factor-cross-section-v1",
        "statistics_version": STATISTICS_VERSION,
        "numeric_policy": dict(NUMERIC_POLICY),
        "settings": settings,
        "factor_definitions": definitions,
        "reports": reports,
        "errors": errors,
        "latest": latest,
        "redundancy": redundancy,
        "input_fingerprint": fingerprint.hexdigest(),
        "start": dates[0].strftime("%Y-%m-%d"),
        "end": dates[-1].strftime("%Y-%m-%d"),
        "date_count": len(dates),
        "assets": len(frames),
        "missing_bars": int(closes.isna().sum().sum()),
        "trade_eligible": False,
        "limitations": [
            "自选样本的回顾性检验，不代表全市场或独立样本外验证；未使用历史成分股。",
            "远期收益是信号日收盘至随后合并观测日收盘的价格变化，不是可成交策略收益；未计成本、涨跌停与停牌。",
            "远期窗口含缺失行情或尚未完成时不参与统计；不填零、不前向补值。",
            "多日收益窗口重叠，信息比率未年化；分层均值不复利为净值。复权数据不保证历史当时可得。",
            "正相关不自动成为买入建议；负相关不自动反转方向。未做行业／市值中性化和多重检验。",
            "数值规则 v2：32 倍 float64 精度的同尺度差异视为并列；因子无固定绝对阈值，"
            "价格比远期收益采用单位算术尺度。近常数不计算相关，标准化不放大其噪声。",
            "分层保留原始收益均值；高低组差在收益算术分辨率内记数值零（不是缺失填零）。容差是明确的工程规则，不是经济显著性或严格误差传播证明。",
        ],
    }
