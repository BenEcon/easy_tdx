"""Selected GTJA191 calculations, independently rewritten in NumPy/pandas.

Reference: DolphinDB's Apache-2.0 module, author DolphinDB, 2023-01-17;
see docs/licenses/dolphindb-Apache-2.0.txt and NOTICE. Changes: Python rewrite,
explicit complete windows/invalid inputs, average-tie percentile panel ranks,
configurable windows and provenance. Not a bit-identical DolphinDB port.
Original mathematical definitions checked against the 2017-06-15 report.
The report itself is not redistributed or relicensed by this module.
"""

from __future__ import annotations

from dataclasses import dataclass, replace
from decimal import Decimal, localcontext
from typing import Any

import numpy as np
import pandas as pd

from easy_tdx.computation import computation_checkpoint
from easy_tdx.factor.base import Factor, PanelFactor, register_factor
from easy_tdx.factor.panel import FactorPanel, cross_section_rank, observation_index

VERSION = "gtja191-complete-window-v2"
SOURCE_COMMIT = "43ace2cc4b81d048864ec2e40c25728d5d464e05"
SOURCE = f"https://github.com/dolphindb/DolphinDBModules/blob/{SOURCE_COMMIT}/gtja191Alpha/src/gtja191Alpha.dos"
REPORT = "https://guorn.com/static/upload/file/3/134065454575605.pdf"


@dataclass(frozen=True)
class Spec:
    number: int
    family: str
    title: str
    inputs: tuple[str, ...]
    window: int | None
    formula: str
    multiplier: int = 1
    offset: int = 0
    panel: bool = False

    @property
    def warmup(self) -> int:
        return max(1, (self.window or 1) * self.multiplier + self.offset)


# C/O/H/L = same-adjustment prices; V = independently qualified shares.
# These descriptions are our concise algebraic notation, not a report table copy.
SPECS: dict[int, Spec] = {}


def _add(
    numbers: dict[int, int | None],
    family: str,
    title: str,
    inputs: tuple[str, ...],
    formula: str,
    *,
    offset: int = 0,
    multiplier: int = 1,
    panel: bool = False,
) -> None:
    for number, window in numbers.items():
        SPECS[number] = Spec(
            number, family, title, inputs, window, formula, multiplier, offset, panel
        )


_add(
    {2: 1},
    "location_delta",
    "收盘位置变化",
    ("close", "high", "low"),
    "位置=(2C−H−L)/(H−L)；输出 w 根前位置−当前位置",
    offset=1,
)
_add(
    {3: 6, 59: 20},
    "buy_pressure",
    "涨跌价格压力和",
    ("close", "high", "low"),
    "持平贡献0；涨时 C−min(L,前收)，跌时 C−max(H,前收)；累计 w 根",
    offset=1,
)
_add(
    {6: 4},
    "rank_weighted_delta",
    "加权价格变动截面排名",
    ("open", "high"),
    "负的截面排名：sign((0.85O+0.15H)−w 根前同值)",
    offset=1,
    panel=True,
)
_add(
    {11: 6, 60: 20},
    "flow_sum",
    "收盘位置量能和",
    ("close", "high", "low", "volume"),
    "累计 w 根：(2C−H−L)/(H−L) × V",
)
_add({14: 5, 106: 20}, "price_delta", "收盘价格差", ("close",), "C−w 根前 C", offset=1)
_add({15: 1}, "open_gap", "开盘相对前收", ("open", "close"), "O/(w 根前 C)−1", offset=1)
_add({18: 5}, "price_ratio", "收盘价格比", ("close",), "C/(w 根前 C)", offset=1)
_add(
    {19: 5},
    "asymmetric_return",
    "对称价格尺度涨跌",
    ("close",),
    "(C−w 根前 C)/max(C,w 根前 C)",
    offset=1,
)
_add(
    {20: 6, 88: 20}, "return_pct", "区间涨跌百分数", ("close",), "100 × (C/(w 根前 C)−1)", offset=1
)
_add(
    {29: 6, 134: 12, 178: 1},
    "volume_return",
    "量加权区间收益",
    ("close", "volume"),
    "(C/(w 根前 C)−1) × V",
    offset=1,
)
_add(
    {31: 12, 66: 6, 71: 24},
    "deviation_pct",
    "收盘均价偏离百分数",
    ("close",),
    "100 × (C/mean_w(C)−1)",
)
_add({34: 12, 65: 6}, "mean_ratio", "均价收盘比", ("close",), "mean_w(C)/C")
_add(
    {43: 6, 84: 20, 94: 30},
    "signed_volume",
    "涨跌方向成交量和",
    ("close", "volume"),
    "累计 w 根：sign(C−前收) × V",
    offset=1,
)
_add(
    {46: 3},
    "four_mean_ratio",
    "四均线收盘比",
    ("close",),
    "mean(mean_w(C),mean_2w(C),mean_4w(C),mean_8w(C))/C",
    multiplier=8,
)
_add(
    {53: 12, 58: 20},
    "up_count_pct",
    "上涨周期百分比",
    ("close",),
    "100 × 最近 w 根 C>前收 的次数 / w",
    offset=1,
)
_add(
    {80: 5},
    "volume_change_pct",
    "成交量变动百分数",
    ("volume",),
    "100 × (V/(w 根前 V)−1)",
    offset=1,
)
_add(
    {97: 10, 100: 20},
    "volume_std",
    "成交量标准差",
    ("volume",),
    "最近 w 根 V 的样本标准差（ddof=1）",
)
_add(
    {110: 20},
    "range_pressure",
    "高低价相对前收压力比",
    ("close", "high", "low"),
    "100 × sum_w(max(H−前收,0))/sum_w(max(前收−L,0))",
    offset=1,
)
_add(
    {118: 20},
    "open_pressure",
    "高低价相对开盘压力比",
    ("open", "high", "low"),
    "100 × sum_w(H−O)/sum_w(O−L)",
)
_add({126: None}, "typical_price", "三价均值", ("close", "high", "low"), "(C+H+L)/3")
_add({129: 12}, "down_sum", "下跌价格幅度和", ("close",), "sum_w(max(前收−C,0))", offset=1)
_add(
    {150: None},
    "typical_volume",
    "三价均值乘成交量",
    ("close", "high", "low", "volume"),
    "(C+H+L)/3 × V；不是实际成交额",
)
_add(
    {153: 3},
    "four_mean",
    "四均线均值",
    ("close",),
    "mean(mean_w(C),mean_2w(C),mean_4w(C),mean_8w(C))",
    multiplier=8,
)
_add(
    {161: 12, 175: 6},
    "true_range_mean",
    "真实波幅均值",
    ("close", "high", "low"),
    "mean_w(max(H−L,abs(H−前收),abs(L−前收)))",
    offset=1,
)
_add({167: 12}, "up_sum", "上涨价格幅度和", ("close",), "sum_w(max(C−前收,0))", offset=1)
_add({168: 20}, "negative_volume_ratio", "负相对成交量", ("volume",), "−V/mean_w(V)")
_add(
    {185: None},
    "rank_body_square",
    "开收偏离平方截面排名",
    ("open", "close"),
    "截面排名：−(1−O/C)²",
    panel=True,
)
_add(
    {187: 20},
    "open_up_pressure",
    "开盘上行价格压力和",
    ("open", "high"),
    "O≤前开时贡献0，否则 max(H−O,O−前开)；累计 w 根",
    offset=1,
)
_add(
    {189: 6},
    "mean_abs_deviation",
    "均价绝对偏差均值",
    ("close",),
    "mean_w(abs(C−mean_w(C)))",
    multiplier=2,
    offset=-1,
)

_add(
    {21: 6, 147: 12},
    "mean_slope",
    "均价时间回归斜率",
    ("close",),
    "以 1…w 为自变量，对最近 w 个 mean_w(C) 做含截距 OLS，取斜率",
    multiplier=2,
    offset=-1,
)
_add(
    {40: 26},
    "up_down_volume_ratio",
    "涨跌成交量比",
    ("close", "volume"),
    "100 × sum_w(C>前收时V否则0) / sum_w(C≤前收时V否则0)",
    offset=1,
)
for _number, _family, _title, _output in (
    (49, "down_range_share", "下移幅度占比", "D/(U+D)"),
    (50, "range_direction_balance", "上下移幅度差占比", "(U−D)/(U+D)"),
    (51, "up_range_share", "上移幅度占比", "U/(U+D)"),
):
    _add(
        {_number: 12},
        _family,
        _title,
        ("high", "low"),
        f"幅度=max(|ΔH|,|ΔL|)；H+L 上移计入 U，下移计入 D，持平不计；累计 w 根后输出 {_output}",
        offset=1,
    )
_add(
    {52: 26},
    "typical_range_pressure",
    "前典型价多空压力比",
    ("close", "high", "low"),
    "T=(H+L+C)/3；100 × sum_w(max(H−前T,0))/sum_w(max(前T−L,0))",
    offset=1,
)
_add(
    {69: 20},
    "open_pressure_balance",
    "开盘多空压力差",
    ("open", "high", "low"),
    "开盘上涨贡献 max(H−O,ΔO) 累计为 U，下跌贡献 max(O−L,ΔO) 累计为 D；"
    "U=D 时0，否则 (U−D)/max(U,D)",
    offset=1,
)
_add(
    {76: 20},
    "volume_scaled_return_cv",
    "量缩放收益变异系数",
    ("close", "volume"),
    "R=|C/前C−1|/V；std_w(R,ddof=1)/mean_w(R)",
    offset=1,
)
_add(
    {86: 10},
    "price_acceleration_switch",
    "价格加速度条件反转",
    ("close",),
    "A=(C[t−2w]−2C[t−w]+C[t])/w；A>0.25 时−1，A<0 时1，否则−ΔC",
    multiplier=2,
    offset=1,
)
_add(
    {93: 20},
    "open_down_pressure",
    "开盘下行价格压力和",
    ("open", "low"),
    "O≥前开时0，否则 max(O−L,O−前开)；累计 w 根",
    offset=1,
)
_add(
    {103: 20},
    "low_recency",
    "窗口低点接近度",
    ("low",),
    "100 × (w−距最近最低点根数)/w；当根最低距离0，并列取最近者",
)
_add(
    {112: 12},
    "price_direction_balance",
    "涨跌幅度差占比",
    ("close",),
    "100 × (sum_w(max(ΔC,0))−sum_w(max(−ΔC,0)))/sum_w(|ΔC|)",
    offset=1,
)
_add(
    {116: 20},
    "price_slope",
    "价格时间回归斜率",
    ("close",),
    "以 1…w 为自变量，对最近 w 个 C 做含截距 OLS，取斜率",
)
_add(
    {127: 12},
    "peak_deviation_rms",
    "滚动峰值偏离均方根",
    ("close",),
    "sqrt(mean_w((100 × (C/max_w(C)−1))²))；外层均值采用同一 w",
    multiplier=2,
    offset=-1,
)
_add(
    {128: 14},
    "typical_money_flow",
    "典型价量流强度",
    ("close", "high", "low", "volume"),
    "T=(H+L+C)/3；上涨 T×V 累计 U，下跌累计 D；100−100/(1+U/D)，D=0 缺失",
    offset=1,
)
_add(
    {133: 20},
    "extreme_recency_balance",
    "高低点接近度差",
    ("high", "low"),
    "100 × (距最近最低点根数−距最近最高点根数)/w；并列取最近者",
)
_add(
    {139: 10},
    "negative_open_volume_corr",
    "开盘成交量负相关",
    ("open", "volume"),
    "−corr_w(O,V)；窗口内任一序列为常数时缺失",
)
_add(
    {158: None},
    "range_close_ratio",
    "振幅收盘比",
    ("close", "high", "low"),
    "(H−L)/C；原式中两项相同 SMA(C,15,2) 代数消去，无额外平滑预热",
)
_add(
    {171: None},
    "body_range_power",
    "开收五次比幅度",
    ("open", "close", "high", "low"),
    "−(L−C)/(C−H) × (O/C)^5；C=H 时缺失",
)
_add(
    {177: 20},
    "high_recency",
    "窗口高点接近度",
    ("high",),
    "100 × (w−距最近最高点根数)/w；当根最高距离0，并列取最近者",
)
_add(
    {191: 20},
    "volume_mean_low_corr",
    "均量低价相关价差",
    ("close", "high", "low", "volume"),
    "corr_5(mean_w(V),L)+(H+L)/2−C；相关窗口固定5根",
    offset=4,
)


def _minimum_window(spec: Spec) -> int:
    return (
        2
        if spec.family
        in {
            "volume_std",
            "volume_scaled_return_cv",
            "mean_slope",
            "price_slope",
            "negative_open_volume_corr",
        }
        else 1
    )


def _rolling_slope(values: pd.Series, window: int) -> pd.Series:
    x = np.arange(window, dtype=float) - (window - 1) / 2
    denominator = float(x @ x)
    return values.rolling(window).apply(lambda y: float(x @ (y - y[0])) / denominator, raw=True)


def _rolling_corr(left: pd.Series, right: pd.Series, window: int) -> pd.Series:
    """Centered/scaled Pearson avoids rolling E[XY]−E[X]E[Y] cancellation."""
    a, b = left.to_numpy(), right.to_numpy()
    out = np.full(len(a), np.nan)
    for end in range(window, len(a) + 1):
        computation_checkpoint()
        x, y = a[end - window : end], b[end - window : end]
        if not (np.isfinite(x).all() and np.isfinite(y).all()):
            continue
        x, y = x - x[0], y - y[0]
        sx, sy = np.max(np.abs(x)), np.max(np.abs(y))
        if sx == 0 or sy == 0:
            continue
        x, y = x / sx, y / sy
        x, y = x - x.mean(), y - y.mean()
        out[end - 1] = np.clip((x @ y) / np.sqrt((x @ x) * (y @ y)), -1, 1)
    return pd.Series(out, index=left.index)


def _extreme_age(values: pd.Series, window: int, *, high: bool) -> pd.Series:
    pick = np.argmax if high else np.argmin
    return values.rolling(window).apply(lambda a: float(pick(a[::-1])), raw=True)


def _sum_direction(*values: pd.Series) -> pd.Series:
    """Compare consecutive decimal price sums without changing equality into a trend."""
    arrays = [value.to_numpy() for value in values]
    result = np.full(len(values[0]), np.nan)
    with localcontext() as context:
        context.prec = 40
        for i in range(1, len(result)):
            computation_checkpoint()
            pairs = [(a[i], a[i - 1]) for a in arrays]
            if not np.isfinite(pairs).all():
                continue
            change = sum(
                (Decimal(str(now)) - Decimal(str(previous)) for now, previous in pairs), Decimal(0)
            )
            result[i] = 1 if change > 0 else -1 if change < 0 else 0
    return pd.Series(result, index=values[0].index)


def _clean(frame: pd.DataFrame, spec: Spec) -> tuple[pd.DataFrame, pd.Series]:
    if (
        frame.columns.has_duplicates
        or frame.index.has_duplicates
        or not frame.index.is_monotonic_increasing
    ):
        raise ValueError("GTJA191 输入索引或字段重复／未递增")
    if "datetime" in frame or "date" in frame or isinstance(frame.index, pd.DatetimeIndex):
        observation_index(frame)
    for identity in ("code", "symbol", "market"):
        if identity in frame and frame[identity].nunique(dropna=False) > 1:
            raise ValueError("GTJA191 单股序列不能混合标的")
    missing = set(spec.inputs) - set(frame.columns)
    if missing:
        raise ValueError(f"GTJA191 缺少字段：{', '.join(sorted(missing))}")
    values = frame.loc[:, list(spec.inputs)].apply(pd.to_numeric, errors="raise").astype(float)
    valid = pd.Series(True, index=frame.index)
    for field in spec.inputs:
        if reason := frame.attrs.get("factor_input_errors", {}).get(field):
            raise ValueError(reason)
        valid &= np.isfinite(values[field]) & (
            values[field].ge(0) if field == "volume" else values[field].gt(0)
        )
    if "high" in values and "low" in values:
        valid &= values.high.ge(values.low)
    for price in ("open", "close"):
        if price in values and "high" in values:
            valid &= values[price].le(values.high)
        if price in values and "low" in values:
            valid &= values[price].ge(values.low)
    return values.where(valid, axis=0), valid


def compute_gtja(frame: pd.DataFrame, spec: Spec) -> pd.Series:
    if spec.panel:
        raise ValueError("此 GTJA191 因子必须使用明确股票池的截面计算")
    data, valid = _clean(frame, spec)
    w = spec.window or 1
    c, h, l, o, v = (data.get(key) for key in ("close", "high", "low", "open", "volume"))  # noqa: E741
    # Only declared inputs are used in each branch; no proxy field substitution.
    f = spec.family
    with np.errstate(divide="ignore", invalid="ignore", over="ignore"):
        if f == "location_delta":
            location = (2 * c - h - l) / (h - l)
            result = location.shift(w) - location
        elif f == "buy_pressure":
            previous = c.shift(1)
            anchor = pd.Series(
                np.where(c > previous, np.minimum(l, previous), np.maximum(h, previous)),
                index=data.index,
            )
            flow = (c - anchor).where(c != previous, 0).where(previous.notna())
            result = flow.rolling(w).sum()
        elif f == "flow_sum":
            result = (
                ((2 * c - h - l) / (h - l) * v).replace([np.inf, -np.inf], np.nan).rolling(w).sum()
            )
        elif f == "price_delta":
            result = c - c.shift(w)
        elif f == "open_gap":
            result = o / c.shift(w) - 1
        elif f == "price_ratio":
            result = c / c.shift(w)
        elif f == "asymmetric_return":
            result = (c - c.shift(w)) / np.maximum(c, c.shift(w))
        elif f == "return_pct":
            result = (c / c.shift(w) - 1) * 100
        elif f == "volume_return":
            result = (c / c.shift(w) - 1) * v
        elif f == "deviation_pct":
            result = (c / c.rolling(w).mean() - 1) * 100
        elif f == "mean_ratio":
            result = c.rolling(w).mean() / c
        elif f == "signed_volume":
            result = (np.sign(c.diff()) * v).rolling(w).sum()
        elif f in {"four_mean", "four_mean_ratio"}:
            result = sum(c.rolling(w * k).mean() for k in (1, 2, 4, 8)) / 4
            if f == "four_mean_ratio":
                result = result / c
        elif f == "up_count_pct":
            result = (c.diff() > 0).astype(float).where(c.diff().notna()).rolling(w).mean() * 100
        elif f == "volume_change_pct":
            result = (v / v.shift(w) - 1) * 100
        elif f == "volume_std":
            result = v.rolling(w).std(ddof=1)
        elif f == "range_pressure":
            result = (
                (h - c.shift(1)).clip(lower=0).rolling(w).sum()
                / (c.shift(1) - l).clip(lower=0).rolling(w).sum()
                * 100
            )
        elif f == "open_pressure":
            result = (h - o).rolling(w).sum() / (o - l).rolling(w).sum() * 100
        elif f == "typical_price":
            result = (c + h + l) / 3
        elif f == "typical_volume":
            result = (c + h + l) / 3 * v
        elif f == "down_sum":
            result = (-c.diff()).clip(lower=0).rolling(w).sum()
        elif f == "up_sum":
            result = c.diff().clip(lower=0).rolling(w).sum()
        elif f == "true_range_mean":
            result = (
                np.maximum(np.maximum(h - l, abs(h - c.shift(1))), abs(l - c.shift(1)))
                .rolling(w)
                .mean()
            )
        elif f == "negative_volume_ratio":
            result = -v / v.rolling(w).mean()
        elif f == "open_up_pressure":
            result = (
                pd.Series(
                    np.where(o > o.shift(1), np.maximum(h - o, o.diff()), 0.0), index=data.index
                )
                .where(o.diff().notna())
                .rolling(w)
                .sum()
            )
        elif f == "mean_abs_deviation":
            result = abs(c - c.rolling(w).mean()).rolling(w).mean()
        elif f in {"mean_slope", "price_slope"}:
            result = _rolling_slope(c.rolling(w).mean() if f == "mean_slope" else c, w)
        elif f == "up_down_volume_ratio":
            up = v.where(c > c.shift(1), 0).rolling(w).sum()
            down = v.where(c <= c.shift(1), 0).rolling(w).sum()
            result = up / down * 100
        elif f in {"down_range_share", "up_range_share", "range_direction_balance"}:
            movement = np.maximum(abs(h.diff()), abs(l.diff()))
            direction = _sum_direction(h, l)
            up = movement.where(direction > 0, 0).rolling(w).sum()
            down = movement.where(direction < 0, 0).rolling(w).sum()
            numerator = (
                down if f == "down_range_share" else up if f == "up_range_share" else up - down
            )
            result = numerator / (up + down)
        elif f == "typical_range_pressure":
            previous = ((h + l + c) / 3).shift(1)
            result = (
                (h - previous).clip(lower=0).rolling(w).sum()
                / ((previous - l).clip(lower=0).rolling(w).sum())
                * 100
            )
        elif f in {"open_pressure_balance", "open_down_pressure"}:
            down = np.maximum(o - l, o.diff()).where(o < o.shift(1), 0).rolling(w).sum()
            if f == "open_down_pressure":
                result = down
            else:
                up = np.maximum(h - o, o.diff()).where(o > o.shift(1), 0).rolling(w).sum()
                result = ((up - down) / np.maximum(up, down)).where(up != down, 0)
        elif f == "volume_scaled_return_cv":
            value = (abs(c / c.shift(1) - 1) / v).replace([np.inf, -np.inf], np.nan)
            result = value.rolling(w).std(ddof=1) / value.rolling(w).mean()
        elif f == "price_acceleration_switch":
            # This is a discontinuous branch, so round-off around 0 / 0.25
            # must not fabricate a different condition. No arbitrary epsilon.
            result = -c.diff()
            with localcontext() as context:
                context.prec = 40
                for i in range(2 * w, len(c)):
                    computation_checkpoint()
                    values = [c.iloc[i - 2 * w], c.iloc[i - w], c.iloc[i]]
                    if not np.isfinite(values).all():
                        continue
                    a, b, z = (Decimal(str(value)) for value in values)
                    change = a - 2 * b + z
                    if change > Decimal("0.25") * w:
                        result.iloc[i] = -1
                    elif change < 0:
                        result.iloc[i] = 1
        elif f in {"low_recency", "high_recency", "extreme_recency_balance"}:
            if f == "extreme_recency_balance":
                result = (_extreme_age(l, w, high=False) - _extreme_age(h, w, high=True)) / w * 100
            else:
                result = (
                    (w - _extreme_age(h if f == "high_recency" else l, w, high=f == "high_recency"))
                    / w
                    * 100
                )
        elif f == "price_direction_balance":
            up, down = (
                c.diff().clip(lower=0).rolling(w).sum(),
                (-c.diff()).clip(lower=0).rolling(w).sum(),
            )
            result = (up - down) / (up + down) * 100
        elif f == "peak_deviation_rms":
            result = np.sqrt(((c / c.rolling(w).max() - 1) * 100).pow(2).rolling(w).mean())
        elif f == "typical_money_flow":
            typical = (h + l + c) / 3
            direction = _sum_direction(h, l, c)
            up = (typical * v).where(direction > 0, 0).rolling(w).sum()
            down = (typical * v).where(direction < 0, 0).rolling(w).sum()
            ratio = (up / down).replace([np.inf, -np.inf], np.nan)
            result = 100 - 100 / (1 + ratio)
        elif f == "negative_open_volume_corr":
            result = -_rolling_corr(o, v, w)
        elif f == "range_close_ratio":
            result = (h - l) / c
        elif f == "body_range_power":
            result = -(l - c) / (c - h) * (o / c).pow(5)
        elif f == "volume_mean_low_corr":
            result = _rolling_corr(v.rolling(w).mean(), l, 5) + (h + l) / 2 - c
        else:
            raise ValueError(f"尚未实现 GTJA191 公式 {spec.number}")
    complete = valid.rolling(spec.warmup).sum().eq(spec.warmup)
    return result.where(complete & np.isfinite(result)).rename(f"gtja191_{spec.number:03d}")


class GTJAFactor(Factor):
    spec: Spec

    def __init__(self, *, window: int | None = None) -> None:
        super().__init__()
        if window is not None:
            minimum = _minimum_window(self.spec)
            maximum = 600 // self.spec.multiplier
            if (
                self.spec.window is None
                or type(window) is not int
                or not minimum <= window <= maximum
            ):
                raise ValueError(f"GTJA191 窗口必须为 {minimum}—{maximum} 的整数，且公式须声明窗口")
            self.spec = replace(self.spec, window=window)

    def compute(self, df: pd.DataFrame) -> pd.Series:
        return compute_gtja(df, self.spec)


class GTJAPanelFactor(GTJAFactor, PanelFactor):
    def compute(self, df: pd.DataFrame) -> pd.Series:
        return PanelFactor.compute(self, df)

    def compute_panel(self, panel: FactorPanel) -> pd.DataFrame:
        fields = {
            key: value.where(np.isfinite(value) & value.gt(0))
            for key, value in panel.fields.items()
        }
        if self.spec.family == "rank_weighted_delta":
            consistent = fields["open"].le(fields["high"])
            fields = {key: value.where(consistent) for key, value in fields.items()}
            w = self.spec.window or 1
            complete = (
                (fields["open"].notna() & fields["high"].notna()).rolling(w + 1).sum().eq(w + 1)
            )
            # SIGN is discontinuous: subtracting weighted binary floats can
            # turn equal decimal prices into opposite ranks. Compare 17O+3H
            # using the decimal round-trip values, without an arbitrary epsilon.
            value = pd.DataFrame(np.nan, index=complete.index, columns=complete.columns)
            with localcontext() as context:
                context.prec = 40
                for symbol in complete.columns:
                    computation_checkpoint()
                    opens, highs = (
                        fields["open"][symbol].to_numpy(),
                        fields["high"][symbol].to_numpy(),
                    )
                    signs = np.full(len(value), np.nan)
                    for i in np.flatnonzero(complete[symbol].to_numpy()):
                        change = 17 * (Decimal(str(opens[i])) - Decimal(str(opens[i - w]))) + 3 * (
                            Decimal(str(highs[i])) - Decimal(str(highs[i - w]))
                        )
                        signs[i] = 1 if change > 0 else -1 if change < 0 else 0
                    value[symbol] = signs
            return -cross_section_rank(value)
        value = -((1 - fields["open"] / fields["close"]) ** 2)
        return cross_section_rank(value.replace([np.inf, -np.inf], np.nan))


def definition_metadata(
    cls: type[GTJAFactor], instance: GTJAFactor | None = None
) -> dict[str, Any]:
    spec = (instance or cls()).spec
    defaults = cls.spec
    return {
        "display_name": f"GTJA {spec.number:03d} · {spec.title}",
        "parameterized_title": f"GTJA {spec.number:03d} · {spec.title}",
        "library": "gtja191",
        "family": spec.family,
        "parameter_family": f"gtja191:{spec.family}",
        "source": SOURCE,
        "source_commit": SOURCE_COMMIT,
        "source_license": "Apache-2.0（参考模块）；原始研报保留版权",
        "original_source": REPORT,
        "formula": spec.formula,
        "implementation_version": VERSION,
        "warmup_bars": spec.warmup,
        "warmup_multiplier": spec.multiplier,
        "warmup_offset": spec.offset,
        "warmup_note": "完整依赖窗口；缺失、非法价格、零分母不填零。",
        "resolved_parameters": {"window": spec.window} if spec.window is not None else {},
        "parameters": {
            "window": {
                "default": defaults.window,
                "value": spec.window,
                "editable": True,
                "min": _minimum_window(spec),
                "max": 600 // spec.multiplier,
                "unit": "bars",
                "label": "基础窗口" if spec.multiplier == 8 else "窗口",
            }
        }
        if spec.window is not None
        else {},
        "status": "available",
        "implemented": True,
        "available": not spec.panel,
        "evaluation_available": True,
        "unavailable_reason": "需要股票池截面检验" if spec.panel else "",
        "evaluation_unavailable_reason": "",
        "data_requirements": list(spec.inputs),
        "supported_adjustments": ["NONE", "QFQ", "HFQ"],
        "limitations": [
            "GTJA191 完整窗口适配；不是逐位复现参考软件。未实现编号不登记为可选项。",
            "原始公式以日线定义；分钟线窗口按 K 线根数解释，不自动换算成交易日。",
            "自定义窗口是原公式参数扩展，不增加标准因子数；均线组保持 1:2:4:8 倍数。",
            "STD 明确使用样本标准差；截面排名为平均并列序号／有效数量，至少两只有效标的。",
            "006 的加权价格符号用输入浮点数往返十进制值比较，避免浮点消减噪音将相等值拆成涨跌。",
            "049—051 与128的价格和方向使用往返十进制比较；相等不计为上涨或下跌。",
            "成交量 V 为已核验的实际股数，不随价格复权逆向缩放；三价均值乘量不等于实际成交额。",
            "数值正负不代表买卖建议，也不自动将负相关反向交易。",
            *(
                {
                    "mean_slope": [
                        "021 使用原报告的均价回归，不沿用参考模块遗漏均价的实现；"
                        "含截距，斜率不除以价格。"
                    ],
                    "peak_deviation_rms": [
                        "127 原表外层均值未写窗口；本适配明确采用参考实现的12根（自定义时同w），"
                        "MAX解释为滚动峰值。"
                    ],
                    "low_recency": ["极值并列时取最近一次；距离按0起算，不按1起算。"],
                    "high_recency": ["极值并列时取最近一次；距离按0起算，不按1起算。"],
                    "extreme_recency_balance": ["极值并列时取最近一次；距离按0起算，不按1起算。"],
                    "body_range_power": [
                        "等价计算先取开收比，避免对价格直接五次幂溢出；收盘等于最高时缺失。"
                    ],
                    "price_acceleration_switch": [
                        "固定阈值0.25使用价格单位，不解释为25%；自定义w同步改变两段距离及除数。",
                        "0及0.25边界以输入价格的往返十进制值比较，避免浮点误差切换条件分支。",
                    ],
                    "range_close_ratio": [
                        "两项相同平滑值在代数上相消；不递归计算与输出无关的平滑状态。"
                    ],
                }.get(spec.family, [])
            ),
        ],
    }


for _spec in SPECS.values():
    register_factor(
        type(
            f"GTJA191{_spec.number:03d}",
            (GTJAPanelFactor if _spec.panel else GTJAFactor,),
            {
                "__module__": __name__,
                "name": f"gtja191_{_spec.number:03d}",
                "category": "volume" if "volume" in _spec.inputs else "technical",
                "description": f"GTJA191 {_spec.number:03d} · {_spec.title}",
                "inputs": _spec.inputs,
                "spec": _spec,
            },
        )
    )
