"""Bounded retrospective cross-sectional diagnostics, not executable returns."""

from __future__ import annotations

import hashlib
import json
from typing import Any

import numpy as np
import pandas as pd

from easy_tdx.computation import computation_checkpoint
from easy_tdx.factor import get_factor
from easy_tdx.factor.catalog import describe_factor


def number(value: Any) -> float | None:
    return float(value) if pd.notna(value) and np.isfinite(value) else None


def correlation(x: pd.Series, y: pd.Series, *, rank: bool = False) -> float | None:
    pair = pd.concat([x, y], axis=1).dropna()
    if len(pair) < 5 or pair.iloc[:, 0].nunique() < 2 or pair.iloc[:, 1].nunique() < 2:
        return None
    if rank:
        pair = pair.rank(method="average")
    return number(pair.iloc[:, 0].corr(pair.iloc[:, 1]))


def prepare_frame(frame: pd.DataFrame) -> pd.DataFrame:
    df = frame.copy()
    time_key = "datetime" if "datetime" in df else "date"
    dates = pd.to_datetime(df[time_key], errors="raise")
    if getattr(dates.dt, "tz", None) is not None:
        dates = dates.dt.tz_convert("Asia/Shanghai").dt.tz_localize(None)
    df.index = pd.DatetimeIndex(dates.dt.normalize())
    if df.index.has_duplicates or not df.index.is_monotonic_increasing:
        raise ValueError("日线日期重复或未按时间递增；已停止因子检验")
    close = pd.to_numeric(df["close"], errors="raise")
    if not np.isfinite(close).all() or (close <= 0).any():
        raise ValueError("收盘价缺失、非正或无效；已停止因子检验")
    return df


def cross_section_report(
    data: dict[str, pd.DataFrame],
    factors: list[str],
    horizon: int,
    groups: int,
    preprocess: str = "raw",
) -> dict[str, Any]:
    """No imputation, no tie splitting, no current membership as historical PIT."""
    if len(data) < 5 or any(frame.empty for frame in data.values()):
        raise ValueError("至少需要 5 只具有行情的标的")
    frames = {symbol: prepare_frame(frame) for symbol, frame in data.items()}
    closes = pd.concat(
        {symbol: frame["close"] for symbol, frame in frames.items()}, axis=1
    ).sort_index()
    dates = closes.index
    # A label requires the entire intervening observed window, including endpoints.
    complete = closes.notna().rolling(horizon + 1).sum().shift(-horizon).eq(horizon + 1)
    returns = (closes.shift(-horizon) / closes - 1).where(complete)
    matrices: dict[str, pd.DataFrame] = {}
    errors: dict[str, str] = {}
    reports: list[dict[str, Any]] = []
    definitions: dict[str, Any] = {}
    for name in factors:
        computation_checkpoint()
        try:
            factor = get_factor(name)()
            definitions[name] = describe_factor(type(factor))
            parts = {}
            for symbol, frame in frames.items():
                for field in factor.inputs:
                    reason = frame.attrs.get("factor_input_errors", {}).get(field)
                    if reason:
                        raise ValueError(f"{symbol} {reason}")
                missing = set(factor.inputs) - set(frame.columns)
                if missing:
                    raise ValueError(f"{symbol} 缺少字段：{', '.join(sorted(missing))}")
                values = factor.compute(frame)
                if not isinstance(values, pd.Series) or not values.index.equals(frame.index):
                    raise ValueError(f"{name} 输出索引与 {symbol} 输入不一致")
                parts[symbol] = values.replace([np.inf, -np.inf], np.nan)
            values = pd.concat(parts, axis=1).reindex(dates)
        except Exception as exc:
            errors[name] = str(exc)
            continue
        raw_coverage = int(values.notna().sum().sum())
        if preprocess == "mad_zscore":
            median = values.median(axis=1)
            mad = values.sub(median, axis=0).abs().median(axis=1) * 1.4826
            # Zero MAD does not collapse every nonmedian observation to the median.
            values = values.clip(
                median - 3 * mad.where(mad > 0), median + 3 * mad.where(mad > 0), axis=0
            )
            values = values.sub(values.mean(axis=1), axis=0).div(
                values.std(axis=1).replace(0, np.nan), axis=0
            )
        matrices[name] = values
        rows: list[dict[str, Any]] = []
        reasons: dict[str, int] = {}
        for date in dates:
            computation_checkpoint()
            pair = pd.concat(
                [values.loc[date].rename("factor"), returns.loc[date].rename("return")], axis=1
            ).dropna()
            reason = None
            ic = rank_ic = None
            layer_values: list[float | None] = [None] * groups
            if len(pair) < max(5, groups):
                reason = "有效标的不足（含预热、缺失或远期窗口未完成）"
            else:
                ic = correlation(pair["factor"], pair["return"])
                rank_ic = correlation(pair["factor"], pair["return"], rank=True)
                if pair["factor"].nunique() < groups:
                    reason = "因子取值过少，不能完整分层"
                else:
                    bins = pd.qcut(pair["factor"], groups, labels=False, duplicates="drop")
                    if bins.nunique() != groups:
                        reason = "分位边界重复，未强拆相同因子值"
                    else:
                        layer_values = [
                            number(pair.loc[bins == q, "return"].mean()) for q in range(groups)
                        ]
                if rank_ic is None and reason is None:
                    reason = "因子或远期收益为常数，相关系数未定义"
            if reason:
                reasons[reason] = reasons.get(reason, 0) + 1
            rows.append(
                {
                    "date": date.strftime("%Y-%m-%d"),
                    "n": len(pair),
                    "ic": ic,
                    "rank_ic": rank_ic,
                    "layers": layer_values,
                    "reason": reason,
                }
            )
        ranked = pd.Series([row["rank_ic"] for row in rows], dtype=float)
        valid = ranked.dropna()
        rolling = ranked.rolling(20, min_periods=20).mean()
        for row, value in zip(rows, rolling, strict=True):
            row["rolling_rank_ic"] = number(value)
        std = valid.std() if len(valid) > 1 else np.nan
        layer_frame = pd.DataFrame([row["layers"] for row in rows], dtype=float)
        layer_means = [number(value) for value in layer_frame.mean()]
        spread = layer_frame.iloc[:, -1] - layer_frame.iloc[:, 0]
        reports.append(
            {
                "name": name,
                "coverage": raw_coverage / max(1, closes.size),
                "observations": len(valid),
                "ic_mean": number(pd.Series([row["ic"] for row in rows], dtype=float).mean()),
                "rank_ic_mean": number(valid.mean()),
                "rank_ic_ir": number(valid.mean() / std) if std > 1e-12 else None,
                "positive_rate": number((valid > 0).mean()) if len(valid) else None,
                "layer_means": layer_means,
                "spread": number(spread.mean()),
                "layer_dates": int(spread.notna().sum()),
                "diagnostics": reasons,
                "daily": rows,
            }
        )
    redundancy = []
    for left in matrices:
        for right in matrices:
            observations = [
                correlation(matrices[left].loc[day], matrices[right].loc[day], rank=True)
                for day in dates
            ]
            sample = pd.Series(observations, dtype=float).dropna()
            redundancy.append(
                {
                    "left": left,
                    "right": right,
                    "correlation": number(sample.mean()),
                    "dates": len(sample),
                }
            )
    latest = [
        {
            "code": code,
            "date": dates[-1].strftime("%Y-%m-%d"),
            **{name: number(matrix.loc[dates[-1], code]) for name, matrix in matrices.items()},
        }
        for code in closes.columns
    ]
    fingerprint = hashlib.sha256()
    for code, frame in frames.items():
        fingerprint.update(code.encode())
        fingerprint.update(pd.util.hash_pandas_object(frame, index=True).values.tobytes())
        fingerprint.update(
            json.dumps(frame.attrs.get("factor_data_contract"), sort_keys=True).encode()
        )
    settings = {"factors": factors, "horizon": horizon, "groups": groups, "preprocess": preprocess}
    fingerprint.update(json.dumps(settings, sort_keys=True).encode())
    fingerprint.update(json.dumps(definitions, sort_keys=True).encode())
    return {
        "version": "factor-cross-section-v1",
        "settings": settings,
        "factor_definitions": definitions,
        "reports": reports,
        "errors": errors,
        "latest": latest,
        "redundancy": redundancy,
        "input_fingerprint": fingerprint.hexdigest(),
        "start": dates[0].strftime("%Y-%m-%d"),
        "end": dates[-1].strftime("%Y-%m-%d"),
        "date_count": len(dates),
        "assets": len(frames),
        "missing_bars": int(closes.isna().sum().sum()),
        "trade_eligible": False,
        "limitations": [
            "自选样本的回顾性检验，不代表全市场或独立样本外验证；未使用历史成分股。",
            "远期收益是信号日收盘至随后合并观测日收盘的价格变化，不是可成交策略收益；未计成本、涨跌停与停牌。",
            "远期窗口含缺失行情或尚未完成时不参与统计；不填零、不前向补值。",
            "多日收益窗口重叠，信息比率未年化；分层均值不复利为净值。复权数据不保证历史当时可得。",
            "正相关不自动成为买入建议；负相关不自动反转方向。未做行业／市值中性化和多重检验。",
        ],
    }
