"""Compute actual finite GTJA coverage on explicitly named hash-checked frozen tapes.

Local acceptance utility, not a live market scanner or a universal availability claim.
Uses test fixtures only; never fetches external data or fills undefined values.
"""

import json
import time

from easy_tdx.factor import FactorEngine, list_factors
from easy_tdx.factor.builtin.gtja191 import SPECS
from easy_tdx.factor.configuration import configure_factor
from tests.unit.test_gtja191_vwap import long_frozen


def main():
    stocks = [
        (0, "000001"),
        (0, "300750"),
        (1, "600036"),
        (0, "000002"),
        (0, "000100"),
        (0, "000725"),
        (1, "600050"),
        (1, "600000"),
        (1, "600015"),
        (1, "601998"),
    ]
    data = {s: long_frozen(f"{m}-{s}-DAILY-NONE.json") for m, s in stocks}
    start = time.monotonic()
    values = []
    for n in sorted(SPECS):
        name = f"gtja191_{n:03d}"
        result = FactorEngine().compute_matrix(data, configure_factor(name))
        values.append(dict(name=name, finite_values=int(result.notna().sum().sum())))
    catalog = list_factors()
    definitions = [r for r in catalog if not r["alias_of"]]
    counts = {}
    for adjust in ("NONE", "QFQ", "HFQ"):
        eligible = [
            r
            for r in definitions
            if r["implemented"] and adjust in r.get("supported_adjustments", ["NONE", "QFQ", "HFQ"])
        ]
        counts[adjust] = {
            "series": sum(r["available"] for r in eligible),
            "evaluation": sum(r["evaluation_available"] for r in eligible),
        }
    print(
        json.dumps(
            dict(
                scope=(
                    "Ten frozen 320-bar NONE tapes; not universal/live/PIT readiness. "
                    "Constant intermediate ranks remain missing."
                ),
                stocks=[s for _, s in stocks],
                seconds=time.monotonic() - start,
                registered=len(catalog),
                definitions=len(definitions),
                implemented=sum(r["implemented"] for r in definitions),
                conditional_ui=counts,
                ready=sum(r["finite_values"] > 0 for r in values),
                factors=values,
            ),
            ensure_ascii=False,
            indent=2,
            allow_nan=False,
        )
    )


if __name__ == "__main__":
    main()
