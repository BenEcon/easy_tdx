"""Per-request factor instances; never mutate registered defaults or user config."""

from __future__ import annotations

from typing import Any

from easy_tdx.factor.base import FACTORY_REGISTRY, Factor


def configure_factor(name: str, parameters: dict[str, Any] | None = None) -> Factor:
    from easy_tdx.factor.builtin.alpha158 import Alpha158Factor

    cls = FACTORY_REGISTRY.get(name)
    if cls is None:
        raise ValueError(f"未知因子：{name}")
    parameters = {} if parameters is None else parameters
    if not isinstance(parameters, dict):
        raise ValueError("因子参数必须是字典")
    if not parameters:
        return cls()
    if issubclass(cls, Alpha158Factor) and cls.spec.window is not None:
        if set(parameters) != {"window"} or type(parameters["window"]) is not int:
            raise ValueError(f"{name} 仅支持整数 window 参数，不接受未声明的参数")
        return cls(window=parameters["window"])
    raise ValueError(f"{name} 目前没有可编辑参数；未忽略传入配置")


def configured_selection(
    names: list[str], parameters: dict[str, dict[str, Any]] | None = None
) -> list[Factor]:
    from easy_tdx.factor.builtin.alpha158 import Alpha158Factor
    from easy_tdx.factor.catalog import canonical_factor_name

    parameters = parameters or {}
    if set(parameters) - set(names):
        raise ValueError("参数含未选中的因子；未静默忽略")
    factors = [configure_factor(name, parameters.get(name)) for name in names]
    identities = [
        ("alpha158", f.spec.family, f.spec.window)
        if isinstance(f, Alpha158Factor)
        else (canonical_factor_name(f.name),)
        for f in factors
    ]
    if len(set(identities)) != len(identities):
        raise ValueError("存在实际参数相同的重复因子；不同默认标识不能重复同一公式")
    return factors
