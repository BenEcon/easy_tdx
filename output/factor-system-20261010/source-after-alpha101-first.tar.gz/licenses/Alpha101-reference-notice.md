# Alpha101 本地适配归属及发布门槛

参考模块作者：DolphinDB；原文件 `wq101alpha/src/wq101alpha.dos`，模块头记载最后修改日期 2022-04-18。

固定仓库提交：43ace2cc4b81d048864ec2e40c25728d5d464e05。
来源：https://github.com/dolphindb/DolphinDBModules/tree/43ace2cc4b81d048864ec2e40c25728d5d464e05/wq101alpha
参考代码依仓库 Apache-2.0 许可，本目录保存完整许可文本。

2026-10-10 修改声明：以 Python/Pandas 重写选定数学计算，新增完整窗口、明确缺失与零分母政策、独立时序／整池执行、逐请求参数、版本指纹、中文目录及独立核验；不依赖 DolphinDB 运行时，不复制整份原论文或参考代码。不声称逐位复现 DolphinDB 的排名／数值约定。

原论文为《101 Formulaic Alphas》，原始权利声明另见 `docs/alpha101-source-audit-20261010.md`。参考代码的 Apache-2.0 许可不被解释为解除第三方的全部权利。用户已同意先本地适配验证；生产部署与对外发布仍须复核许可。本地可计算数与生产已部署数分别统计。
