"""Selected Alpha101 formulas, locally adapted from DolphinDB's Apache-2.0 module.

Reference author: DolphinDB; commit 43ace2cc4b81d048864ec2e40c25728d5d464e05.
Modified 2026-10-10: original Python implementation, explicit complete windows,
missing values, stable correlation, configuration and panel execution. See
licenses/Alpha101-reference-notice.md and DolphinDB-Apache-2.0.txt.
Local validation is authorized; production redistribution review is outstanding.
"""

from __future__ import annotations

from dataclasses import dataclass, replace
from typing import Any

import numpy as np
import pandas as pd

from easy_tdx.computation import computation_checkpoint
from easy_tdx.factor.base import Factor, PanelFactor, register_factor
from easy_tdx.factor.panel import FactorPanel, cross_section_rank

VERSION = "alpha101-complete-window-v1"
COMMIT = "43ace2cc4b81d048864ec2e40c25728d5d464e05"
SOURCE = (
    f"https://github.com/dolphindb/DolphinDBModules/blob/{COMMIT}/wq101alpha/src/wq101alpha.dos"
)


@dataclass(frozen=True)
class Spec:
    number: int
    title: str
    inputs: tuple[str, ...]
    formula: str
    window: int | None = None
    panel: bool = False

    @property
    def warmup(self) -> int:
        w = self.window or 1
        return w + 1 if self.number in {9, 12, 53} else max(w, 3) if self.number == 23 else w


SPECS = {
    3: Spec(
        3,
        "开盘与成交量截面排序相关",
        ("open", "volume"),
        "-corr(cs_rank(open), cs_rank(volume), window)",
        10,
        True,
    ),
    4: Spec(4, "最低价截面排序的时序位置", ("low",), "-ts_rank(cs_rank(low), window)", 9, True),
    6: Spec(6, "开盘与成交量反向相关", ("open", "volume"), "-corr(open, volume, window)", 10),
    9: Spec(
        9,
        "连续价差条件方向",
        ("close",),
        "d=diff(close,1); min(d,window)>0 or max(d,window)<0 ? d : -d",
        5,
    ),
    12: Spec(
        12,
        "量差方向与反向价差",
        ("close", "volume"),
        "sign(diff(volume,window)) * -diff(close,window)",
        1,
    ),
    23: Spec(23, "高价突破条件变化", ("high",), "high>mean(high,window) ? -diff(high,2) : 0", 20),
    53: Spec(
        53,
        "收盘区间比变化",
        ("close", "high", "low"),
        "-diff(((close-low)-(high-close))/(close-low),window)",
        9,
    ),
    101: Spec(
        101, "开收盘差相对振幅", ("close", "open", "high", "low"), "(close-open)/(high-low+0.001)"
    ),
}


def correlation(left: pd.Series, right: pd.Series, window: int) -> pd.Series:
    """Local centered/scaled Pearson; no epsilon denominator or stale rolling sum."""
    out = np.full(len(left), np.nan)
    x, y = left.to_numpy(float), right.to_numpy(float)
    for end in range(window - 1, len(left)):
        computation_checkpoint()
        a, b = x[end + 1 - window : end + 1], y[end + 1 - window : end + 1]
        if not (np.isfinite(a).all() and np.isfinite(b).all()):
            continue
        centered = []
        for values in (a, b):
            scale = np.max(np.abs(values))
            scaled = values / scale if scale else values
            delta = scaled - scaled.mean()
            norm = np.linalg.norm(delta)
            if norm <= 1e-12:
                break
            centered.append(delta / norm)
        if len(centered) == 2:
            out[end] = np.clip(np.dot(*centered), -1, 1)
    return pd.Series(out, index=left.index)


def clean(frame: pd.DataFrame, spec: Spec) -> pd.DataFrame:
    if frame.columns.has_duplicates or set(spec.inputs) - set(frame):
        raise ValueError("Alpha101 输入缺失或重复；不使用替代字段")
    for field in spec.inputs:
        reason = frame.attrs.get("factor_input_errors", {}).get(field)
        if reason:
            raise ValueError(str(reason))
    data = frame[list(spec.inputs)].apply(pd.to_numeric, errors="raise").astype(float)
    data = data.replace([np.inf, -np.inf], np.nan)
    for field in spec.inputs:
        data[field] = data[field].where(
            data[field].ge(0) if field == "volume" else data[field].gt(0)
        )
    if {"high", "low"} <= set(data):
        prices = [key for key in ("open", "close", "high", "low") if key in data]
        valid = data.high.ge(data[prices].max(axis=1)) & data.low.le(data[prices].min(axis=1))
        data = data.where(valid, np.nan)
    return data


def compute_series(frame: pd.DataFrame, spec: Spec) -> pd.Series:
    computation_checkpoint()
    if spec.panel:
        raise ValueError("Alpha101 截面因子需要明确股票池，不能用单股代替")
    data = clean(frame, spec)
    w = spec.window or 1
    with np.errstate(all="ignore"):
        if spec.number == 6:
            result = -correlation(data.open, data.volume, w)
        elif spec.number == 9:
            delta = data.close.diff()
            same = delta.rolling(w).min().gt(0) | delta.rolling(w).max().lt(0)
            result = delta.where(same, -delta)
        elif spec.number == 12:
            result = np.sign(data.volume.diff(w)) * -data.close.diff(w)
        elif spec.number == 23:
            result = -data.high.diff(2).where(data.high.gt(data.high.rolling(w).mean()), 0.0)
        elif spec.number == 53:
            ratio = ((data.close - data.low) - (data.high - data.close)) / (data.close - data.low)
            result = -ratio.replace([np.inf, -np.inf], np.nan).diff(w)
        elif spec.number == 101:
            result = (data.close - data.open) / (data.high - data.low + 0.001)
        else:
            raise ValueError("未实现的 Alpha101 编号")
    valid = data.notna().all(axis=1).astype(int).rolling(spec.warmup).sum().eq(spec.warmup)
    return result.where(valid & np.isfinite(result)).rename(f"alpha101_{spec.number:03d}")


class Alpha101Factor(Factor):
    spec: Spec

    def __init__(self, *, window: int | None = None) -> None:
        super().__init__()
        if window is not None:
            minimum = 2 if self.spec.number in {3, 6} else 1
            if self.spec.window is None or type(window) is not int or not minimum <= window <= 500:
                raise ValueError("Alpha101 窗口须为声明范围内的整数，不接受布尔值")
            self.spec = replace(self.spec, window=window)

    def compute(self, df: pd.DataFrame) -> pd.Series:
        return compute_series(df, self.spec)


class Alpha101PanelFactor(Alpha101Factor, PanelFactor):
    def compute_panel(self, panel: FactorPanel) -> pd.DataFrame:
        computation_checkpoint()
        ranks = {}
        for field in self.inputs:
            values = panel.fields[field]
            valid = values.ge(0) if field == "volume" else values.gt(0)
            ranks[field] = cross_section_rank(values.where(valid))
        w = self.spec.window or 1
        if self.spec.number == 3:
            result = pd.DataFrame(
                {
                    symbol: -correlation(ranks["open"][symbol], ranks["volume"][symbol], w)
                    for symbol in panel.observed.columns
                }
            )
        elif self.spec.number == 4:
            result = -ranks["low"].rolling(w, min_periods=w).rank(method="average", pct=True)
        else:
            raise ValueError("未实现的 Alpha101 整池编号")
        computation_checkpoint()
        return panel.validate_result(result, self.name)


def definition_metadata(
    cls: type[Alpha101Factor], instance: Alpha101Factor | None = None
) -> dict[str, Any]:
    spec = (instance or cls()).spec
    return {
        "display_name": f"Alpha101 {spec.number:03d} · {spec.title}",
        "parameterized_title": f"Alpha101 {spec.number:03d} · {spec.title}",
        "library": "alpha101",
        "family": f"alpha101_{spec.number:03d}",
        "parameter_family": f"alpha101_{spec.number:03d}",
        "formula": spec.formula,
        "source": SOURCE,
        "source_commit": COMMIT,
        "source_license": "Apache-2.0（DolphinDB 参考模块）；生产发布待许可复核",
        "original_source": "https://arxiv.org/abs/1601.00991v3",
        "implementation_version": VERSION,
        "release_status": "local_validation_only_pending_license_review",
        "warmup_bars": spec.warmup,
        "warmup_terms": (
            [{"offset": 0, "windows": ["window"]}, {"offset": 3, "windows": []}]
            if spec.number == 23
            else [{"offset": 1 if spec.number in {9, 12, 53} else 0, "windows": ["window"]}]
            if spec.window is not None
            else [{"offset": 1, "windows": []}]
        ),
        "warmup_note": "完整依赖窗口；缺失与非法输入不填零。常数相关或零分母可继续为空。",
        "resolved_parameters": {"window": spec.window} if spec.window is not None else {},
        "parameters": {
            "window": {
                "default": cls.spec.window,
                "value": spec.window,
                "editable": True,
                "min": 2 if spec.number in {3, 6} else 1,
                "max": 500,
                "unit": "bars",
                "label": "窗口",
            }
        }
        if spec.window is not None
        else {},
        "implemented": True,
        "status": "available",
        "available": not spec.panel,
        "evaluation_available": True,
        "evaluation_unavailable_reason": "",
        "unavailable_reason": "需要明确股票池截面检验" if spec.panel else "",
        "data_requirements": list(spec.inputs),
        "supported_adjustments": ["NONE", "QFQ", "HFQ"],
        "limitations": [
            "仅授权本地适配验证；生产发布待许可复核，不表示原论文全部权利已解除。",
            "原参考基于日线；其它周期为明确的按当前 K 线根数推广，不换算交易日。",
            "截面 rank 为同日有效标的平均并列序号/数量，至少2个标的；"
            "ts_rank 同样平均并列并归一到(0,1]。",
            "完整窗口内缺失不跨过；量为实际成交股数，不替换为成交额或复权伪成交量。",
            "相关先按各自窗口最大绝对值缩放并中心化；中心化范数≤1e−12视为无定义，不制造零相关。",
            "101号保留固定价格常数0.001，故对价格单位及复权敏感；53号收盘等于最低价时分母为零，留空。",
            "数值方向不自动解释为买卖建议；参数变化不增加标准因子数量。",
        ],
    }


for _spec in SPECS.values():
    register_factor(
        type(
            f"Alpha101{_spec.number:03d}",
            (Alpha101PanelFactor if _spec.panel else Alpha101Factor,),
            {
                "__module__": __name__,
                "name": f"alpha101_{_spec.number:03d}",
                "category": "volume" if "volume" in _spec.inputs else "technical",
                "description": _spec.title,
                "inputs": _spec.inputs,
                "spec": _spec,
            },
        )
    )
