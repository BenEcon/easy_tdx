"""Selected GTJA191 calculations, independently rewritten in NumPy/pandas.

Reference: DolphinDB's Apache-2.0 module, author DolphinDB, 2023-01-17;
see docs/licenses/dolphindb-Apache-2.0.txt and NOTICE. Changes: Python rewrite,
explicit complete windows/invalid inputs, average-tie percentile panel ranks,
configurable windows and provenance. Not a bit-identical DolphinDB port.
Original mathematical definitions checked against the 2017-06-15 report.
The report itself is not redistributed or relicensed by this module.
"""

from __future__ import annotations

from dataclasses import dataclass, replace
from decimal import Decimal, localcontext
from typing import Any

import numpy as np
import pandas as pd

from easy_tdx.computation import computation_checkpoint
from easy_tdx.factor.base import Factor, PanelFactor, register_factor
from easy_tdx.factor.panel import FactorPanel, cross_section_rank, observation_index

VERSION = "gtja191-complete-window-v1"
SOURCE_COMMIT = "43ace2cc4b81d048864ec2e40c25728d5d464e05"
SOURCE = f"https://github.com/dolphindb/DolphinDBModules/blob/{SOURCE_COMMIT}/gtja191Alpha/src/gtja191Alpha.dos"
REPORT = "https://guorn.com/static/upload/file/3/134065454575605.pdf"


@dataclass(frozen=True)
class Spec:
    number: int
    family: str
    title: str
    inputs: tuple[str, ...]
    window: int | None
    formula: str
    multiplier: int = 1
    offset: int = 0
    panel: bool = False

    @property
    def warmup(self) -> int:
        return max(1, (self.window or 1) * self.multiplier + self.offset)


# C/O/H/L = same-adjustment prices; V = independently qualified shares.
# These descriptions are our concise algebraic notation, not a report table copy.
SPECS: dict[int, Spec] = {}


def _add(
    numbers: dict[int, int | None],
    family: str,
    title: str,
    inputs: tuple[str, ...],
    formula: str,
    *,
    offset: int = 0,
    multiplier: int = 1,
    panel: bool = False,
) -> None:
    for number, window in numbers.items():
        SPECS[number] = Spec(
            number, family, title, inputs, window, formula, multiplier, offset, panel
        )


_add(
    {2: 1},
    "location_delta",
    "收盘位置变化",
    ("close", "high", "low"),
    "位置=(2C−H−L)/(H−L)；输出 w 根前位置−当前位置",
    offset=1,
)
_add(
    {3: 6, 59: 20},
    "buy_pressure",
    "涨跌价格压力和",
    ("close", "high", "low"),
    "持平贡献0；涨时 C−min(L,前收)，跌时 C−max(H,前收)；累计 w 根",
    offset=1,
)
_add(
    {6: 4},
    "rank_weighted_delta",
    "加权价格变动截面排名",
    ("open", "high"),
    "负的截面排名：sign((0.85O+0.15H)−w 根前同值)",
    offset=1,
    panel=True,
)
_add(
    {11: 6, 60: 20},
    "flow_sum",
    "收盘位置量能和",
    ("close", "high", "low", "volume"),
    "累计 w 根：(2C−H−L)/(H−L) × V",
)
_add({14: 5, 106: 20}, "price_delta", "收盘价格差", ("close",), "C−w 根前 C", offset=1)
_add({15: 1}, "open_gap", "开盘相对前收", ("open", "close"), "O/(w 根前 C)−1", offset=1)
_add({18: 5}, "price_ratio", "收盘价格比", ("close",), "C/(w 根前 C)", offset=1)
_add(
    {19: 5},
    "asymmetric_return",
    "对称价格尺度涨跌",
    ("close",),
    "(C−w 根前 C)/max(C,w 根前 C)",
    offset=1,
)
_add(
    {20: 6, 88: 20}, "return_pct", "区间涨跌百分数", ("close",), "100 × (C/(w 根前 C)−1)", offset=1
)
_add(
    {29: 6, 134: 12, 178: 1},
    "volume_return",
    "量加权区间收益",
    ("close", "volume"),
    "(C/(w 根前 C)−1) × V",
    offset=1,
)
_add(
    {31: 12, 66: 6, 71: 24},
    "deviation_pct",
    "收盘均价偏离百分数",
    ("close",),
    "100 × (C/mean_w(C)−1)",
)
_add({34: 12, 65: 6}, "mean_ratio", "均价收盘比", ("close",), "mean_w(C)/C")
_add(
    {43: 6, 84: 20, 94: 30},
    "signed_volume",
    "涨跌方向成交量和",
    ("close", "volume"),
    "累计 w 根：sign(C−前收) × V",
    offset=1,
)
_add(
    {46: 3},
    "four_mean_ratio",
    "四均线收盘比",
    ("close",),
    "mean(mean_w(C),mean_2w(C),mean_4w(C),mean_8w(C))/C",
    multiplier=8,
)
_add(
    {53: 12, 58: 20},
    "up_count_pct",
    "上涨周期百分比",
    ("close",),
    "100 × 最近 w 根 C>前收 的次数 / w",
    offset=1,
)
_add(
    {80: 5},
    "volume_change_pct",
    "成交量变动百分数",
    ("volume",),
    "100 × (V/(w 根前 V)−1)",
    offset=1,
)
_add(
    {97: 10, 100: 20},
    "volume_std",
    "成交量标准差",
    ("volume",),
    "最近 w 根 V 的样本标准差（ddof=1）",
)
_add(
    {110: 20},
    "range_pressure",
    "高低价相对前收压力比",
    ("close", "high", "low"),
    "100 × sum_w(max(H−前收,0))/sum_w(max(前收−L,0))",
    offset=1,
)
_add(
    {118: 20},
    "open_pressure",
    "高低价相对开盘压力比",
    ("open", "high", "low"),
    "100 × sum_w(H−O)/sum_w(O−L)",
)
_add({126: None}, "typical_price", "三价均值", ("close", "high", "low"), "(C+H+L)/3")
_add({129: 12}, "down_sum", "下跌价格幅度和", ("close",), "sum_w(max(前收−C,0))", offset=1)
_add(
    {150: None},
    "typical_volume",
    "三价均值乘成交量",
    ("close", "high", "low", "volume"),
    "(C+H+L)/3 × V；不是实际成交额",
)
_add(
    {153: 3},
    "four_mean",
    "四均线均值",
    ("close",),
    "mean(mean_w(C),mean_2w(C),mean_4w(C),mean_8w(C))",
    multiplier=8,
)
_add(
    {161: 12, 175: 6},
    "true_range_mean",
    "真实波幅均值",
    ("close", "high", "low"),
    "mean_w(max(H−L,abs(H−前收),abs(L−前收)))",
    offset=1,
)
_add({167: 12}, "up_sum", "上涨价格幅度和", ("close",), "sum_w(max(C−前收,0))", offset=1)
_add({168: 20}, "negative_volume_ratio", "负相对成交量", ("volume",), "−V/mean_w(V)")
_add(
    {185: None},
    "rank_body_square",
    "开收偏离平方截面排名",
    ("open", "close"),
    "截面排名：−(1−O/C)²",
    panel=True,
)
_add(
    {187: 20},
    "open_up_pressure",
    "开盘上行价格压力和",
    ("open", "high"),
    "O≤前开时贡献0，否则 max(H−O,O−前开)；累计 w 根",
    offset=1,
)
_add(
    {189: 6},
    "mean_abs_deviation",
    "均价绝对偏差均值",
    ("close",),
    "mean_w(abs(C−mean_w(C)))",
    multiplier=2,
    offset=-1,
)


def _clean(frame: pd.DataFrame, spec: Spec) -> tuple[pd.DataFrame, pd.Series]:
    if (
        frame.columns.has_duplicates
        or frame.index.has_duplicates
        or not frame.index.is_monotonic_increasing
    ):
        raise ValueError("GTJA191 输入索引或字段重复／未递增")
    if "datetime" in frame or "date" in frame or isinstance(frame.index, pd.DatetimeIndex):
        observation_index(frame)
    for identity in ("code", "symbol", "market"):
        if identity in frame and frame[identity].nunique(dropna=False) > 1:
            raise ValueError("GTJA191 单股序列不能混合标的")
    missing = set(spec.inputs) - set(frame.columns)
    if missing:
        raise ValueError(f"GTJA191 缺少字段：{', '.join(sorted(missing))}")
    values = frame.loc[:, list(spec.inputs)].apply(pd.to_numeric, errors="raise").astype(float)
    valid = pd.Series(True, index=frame.index)
    for field in spec.inputs:
        if reason := frame.attrs.get("factor_input_errors", {}).get(field):
            raise ValueError(reason)
        valid &= np.isfinite(values[field]) & (
            values[field].ge(0) if field == "volume" else values[field].gt(0)
        )
    if "high" in values and "low" in values:
        valid &= values.high.ge(values.low)
    for price in ("open", "close"):
        if price in values and "high" in values:
            valid &= values[price].le(values.high)
        if price in values and "low" in values:
            valid &= values[price].ge(values.low)
    return values.where(valid, axis=0), valid


def compute_gtja(frame: pd.DataFrame, spec: Spec) -> pd.Series:
    if spec.panel:
        raise ValueError("此 GTJA191 因子必须使用明确股票池的截面计算")
    data, valid = _clean(frame, spec)
    w = spec.window or 1
    c, h, l, o, v = (data.get(key) for key in ("close", "high", "low", "open", "volume"))  # noqa: E741
    # Only declared inputs are used in each branch; no proxy field substitution.
    f = spec.family
    with np.errstate(divide="ignore", invalid="ignore", over="ignore"):
        if f == "location_delta":
            location = (2 * c - h - l) / (h - l)
            result = location.shift(w) - location
        elif f == "buy_pressure":
            previous = c.shift(1)
            anchor = pd.Series(
                np.where(c > previous, np.minimum(l, previous), np.maximum(h, previous)),
                index=data.index,
            )
            flow = (c - anchor).where(c != previous, 0).where(previous.notna())
            result = flow.rolling(w).sum()
        elif f == "flow_sum":
            result = (
                ((2 * c - h - l) / (h - l) * v).replace([np.inf, -np.inf], np.nan).rolling(w).sum()
            )
        elif f == "price_delta":
            result = c - c.shift(w)
        elif f == "open_gap":
            result = o / c.shift(w) - 1
        elif f == "price_ratio":
            result = c / c.shift(w)
        elif f == "asymmetric_return":
            result = (c - c.shift(w)) / np.maximum(c, c.shift(w))
        elif f == "return_pct":
            result = (c / c.shift(w) - 1) * 100
        elif f == "volume_return":
            result = (c / c.shift(w) - 1) * v
        elif f == "deviation_pct":
            result = (c / c.rolling(w).mean() - 1) * 100
        elif f == "mean_ratio":
            result = c.rolling(w).mean() / c
        elif f == "signed_volume":
            result = (np.sign(c.diff()) * v).rolling(w).sum()
        elif f in {"four_mean", "four_mean_ratio"}:
            result = sum(c.rolling(w * k).mean() for k in (1, 2, 4, 8)) / 4
            if f == "four_mean_ratio":
                result = result / c
        elif f == "up_count_pct":
            result = (c.diff() > 0).astype(float).where(c.diff().notna()).rolling(w).mean() * 100
        elif f == "volume_change_pct":
            result = (v / v.shift(w) - 1) * 100
        elif f == "volume_std":
            result = v.rolling(w).std(ddof=1)
        elif f == "range_pressure":
            result = (
                (h - c.shift(1)).clip(lower=0).rolling(w).sum()
                / (c.shift(1) - l).clip(lower=0).rolling(w).sum()
                * 100
            )
        elif f == "open_pressure":
            result = (h - o).rolling(w).sum() / (o - l).rolling(w).sum() * 100
        elif f == "typical_price":
            result = (c + h + l) / 3
        elif f == "typical_volume":
            result = (c + h + l) / 3 * v
        elif f == "down_sum":
            result = (-c.diff()).clip(lower=0).rolling(w).sum()
        elif f == "up_sum":
            result = c.diff().clip(lower=0).rolling(w).sum()
        elif f == "true_range_mean":
            result = (
                np.maximum(np.maximum(h - l, abs(h - c.shift(1))), abs(l - c.shift(1)))
                .rolling(w)
                .mean()
            )
        elif f == "negative_volume_ratio":
            result = -v / v.rolling(w).mean()
        elif f == "open_up_pressure":
            result = (
                pd.Series(
                    np.where(o > o.shift(1), np.maximum(h - o, o.diff()), 0.0), index=data.index
                )
                .where(o.diff().notna())
                .rolling(w)
                .sum()
            )
        elif f == "mean_abs_deviation":
            result = abs(c - c.rolling(w).mean()).rolling(w).mean()
        else:
            raise ValueError(f"尚未实现 GTJA191 公式 {spec.number}")
    complete = valid.rolling(spec.warmup).sum().eq(spec.warmup)
    return result.where(complete & np.isfinite(result)).rename(f"gtja191_{spec.number:03d}")


class GTJAFactor(Factor):
    spec: Spec

    def __init__(self, *, window: int | None = None) -> None:
        super().__init__()
        if window is not None:
            minimum = 2 if self.spec.family == "volume_std" else 1
            maximum = 600 // self.spec.multiplier
            if (
                self.spec.window is None
                or type(window) is not int
                or not minimum <= window <= maximum
            ):
                raise ValueError(f"GTJA191 窗口必须为 {minimum}—{maximum} 的整数，且公式须声明窗口")
            self.spec = replace(self.spec, window=window)

    def compute(self, df: pd.DataFrame) -> pd.Series:
        return compute_gtja(df, self.spec)


class GTJAPanelFactor(GTJAFactor, PanelFactor):
    def compute(self, df: pd.DataFrame) -> pd.Series:
        return PanelFactor.compute(self, df)

    def compute_panel(self, panel: FactorPanel) -> pd.DataFrame:
        fields = {
            key: value.where(np.isfinite(value) & value.gt(0))
            for key, value in panel.fields.items()
        }
        if self.spec.family == "rank_weighted_delta":
            consistent = fields["open"].le(fields["high"])
            fields = {key: value.where(consistent) for key, value in fields.items()}
            w = self.spec.window or 1
            complete = (
                (fields["open"].notna() & fields["high"].notna()).rolling(w + 1).sum().eq(w + 1)
            )
            # SIGN is discontinuous: subtracting weighted binary floats can
            # turn equal decimal prices into opposite ranks. Compare 17O+3H
            # using the decimal round-trip values, without an arbitrary epsilon.
            value = pd.DataFrame(np.nan, index=complete.index, columns=complete.columns)
            with localcontext() as context:
                context.prec = 40
                for symbol in complete.columns:
                    computation_checkpoint()
                    opens, highs = (
                        fields["open"][symbol].to_numpy(),
                        fields["high"][symbol].to_numpy(),
                    )
                    signs = np.full(len(value), np.nan)
                    for i in np.flatnonzero(complete[symbol].to_numpy()):
                        change = 17 * (Decimal(str(opens[i])) - Decimal(str(opens[i - w]))) + 3 * (
                            Decimal(str(highs[i])) - Decimal(str(highs[i - w]))
                        )
                        signs[i] = 1 if change > 0 else -1 if change < 0 else 0
                    value[symbol] = signs
            return -cross_section_rank(value)
        value = -((1 - fields["open"] / fields["close"]) ** 2)
        return cross_section_rank(value.replace([np.inf, -np.inf], np.nan))


def definition_metadata(
    cls: type[GTJAFactor], instance: GTJAFactor | None = None
) -> dict[str, Any]:
    spec = (instance or cls()).spec
    defaults = cls.spec
    return {
        "display_name": f"GTJA {spec.number:03d} · {spec.title}",
        "parameterized_title": f"GTJA {spec.number:03d} · {spec.title}",
        "library": "gtja191",
        "family": spec.family,
        "parameter_family": f"gtja191:{spec.family}",
        "source": SOURCE,
        "source_commit": SOURCE_COMMIT,
        "source_license": "Apache-2.0（参考模块）；原始研报保留版权",
        "original_source": REPORT,
        "formula": spec.formula,
        "implementation_version": VERSION,
        "warmup_bars": spec.warmup,
        "warmup_multiplier": spec.multiplier,
        "warmup_offset": spec.offset,
        "warmup_note": "完整依赖窗口；缺失、非法价格、零分母不填零。",
        "resolved_parameters": {"window": spec.window} if spec.window is not None else {},
        "parameters": {
            "window": {
                "default": defaults.window,
                "value": spec.window,
                "editable": True,
                "min": 2 if spec.family == "volume_std" else 1,
                "max": 600 // spec.multiplier,
                "unit": "bars",
                "label": "基础窗口" if spec.multiplier == 8 else "窗口",
            }
        }
        if spec.window is not None
        else {},
        "status": "available",
        "implemented": True,
        "available": not spec.panel,
        "evaluation_available": True,
        "unavailable_reason": "需要股票池截面检验" if spec.panel else "",
        "evaluation_unavailable_reason": "",
        "data_requirements": list(spec.inputs),
        "supported_adjustments": ["NONE", "QFQ", "HFQ"],
        "limitations": [
            "GTJA191 完整窗口适配；不是逐位复现参考软件。未实现编号不登记为可选项。",
            "原始公式以日线定义；分钟线窗口按 K 线根数解释，不自动换算成交易日。",
            "自定义窗口是原公式参数扩展，不增加标准因子数；均线组保持 1:2:4:8 倍数。",
            "STD 明确使用样本标准差；截面排名为平均并列序号／有效数量，至少两只有效标的。",
            "006 的加权价格符号用输入浮点数往返十进制值比较，避免浮点消减噪音将相等值拆成涨跌。",
            "成交量 V 为已核验的实际股数，不随价格复权逆向缩放；三价均值乘量不等于实际成交额。",
            "数值正负不代表买卖建议，也不自动将负相关反向交易。",
        ],
    }


for _spec in SPECS.values():
    register_factor(
        type(
            f"GTJA191{_spec.number:03d}",
            (GTJAPanelFactor if _spec.panel else GTJAFactor,),
            {
                "__module__": __name__,
                "name": f"gtja191_{_spec.number:03d}",
                "category": "volume" if "volume" in _spec.inputs else "technical",
                "description": f"GTJA191 {_spec.number:03d} · {_spec.title}",
                "inputs": _spec.inputs,
                "spec": _spec,
            },
        )
    )
