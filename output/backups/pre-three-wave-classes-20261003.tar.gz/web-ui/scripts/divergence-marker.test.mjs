import test from 'node:test'
import assert from 'node:assert/strict'
import { divergenceMarker, macdPrompts } from '../src/divergence-marker.ts'
import { divergenceName, divergenceEvidence } from '../src/divergence-evidence.ts'

test('direction, family and lifecycle have independent marker styles', () => {
  for (const direction of ['up', 'down']) {
    for (const type of ['macd', 'macd_wave', 'qs', 'pz']) {
      const base = { bc: true, type, direction }
      const pending = divergenceMarker({ ...base, status: 'candidate' })
      const confirmed = divergenceMarker({ ...base, status: 'confirmed' })
      assert.equal(pending.symbol, type === 'macd' ? 'circle' : 'diamond')
      assert.equal(pending.itemStyle.color, 'transparent')
      assert.equal(pending.itemStyle.borderType, 'dashed')
      assert.equal(confirmed.itemStyle.color, direction === 'up' ? '#61dfa0' : '#cf8ff5')
      assert.equal(confirmed.itemStyle.borderType, 'solid')
      assert.equal(divergenceMarker({ ...base, status: 'superseded' }), null)
      assert.equal(divergenceMarker({ ...base, bc: false }), null)
    }
  }
})

test('no-C dual-line diamond replaces the circle and only fills on reverse-pen confirmation', () => {
  for (const direction of ['up', 'down']) {
    const base = { bc: true, type: 'macd', direction, status: 'candidate', signal_index: 10,
      evidence: { special_no_c: 1, price: 19, previous_price: 20, dif: -.5, previous_dif: -1,
        dea: -.7, previous_dea: -1.2 } }
    const pending = divergenceMarker(base)
    assert.equal(pending.symbol, 'diamond')
    assert.equal(pending.symbolSize, 13)
    assert.equal(pending.itemStyle.color, 'transparent')
    assert.equal(pending.itemStyle.borderType, 'dashed')
    assert.match(divergenceName(base), /特殊双线/)
    assert.match(divergenceEvidence(base).join('\n'), /最近局部高／低点/)
    assert.match(divergenceEvidence(base).join('\n'), /不作为标准波段背离或 M1/)
    const complete = { ...base, status: 'confirmed', confirmed_index: 18,
      evidence: { ...base.evidence, reverse_pen_start: 10, reverse_pen_end: 14, reverse_pen_confirmed: 18 } }
    assert.equal(divergenceMarker(complete).itemStyle.color, direction === 'up' ? '#61dfa0' : '#cf8ff5')
    assert.equal(divergenceMarker(complete).itemStyle.borderType, 'solid')
    assert.deepEqual(macdPrompts([complete]), [])
    for (const item of [{ ...base, preliminary_index: 12 }, { ...complete, confirmed_index: 10 },
      { ...complete, evidence: { ...complete.evidence, reverse_pen_start: 9 } },
      { ...complete, evidence: base.evidence }]) {
      assert.equal(divergenceMarker(item).itemStyle.color, 'transparent')
    }
    assert.equal(divergenceMarker({ ...base, status: 'superseded' }), null)
    assert.equal(divergenceMarker({ ...base, evidence: {} }).symbol, 'circle')
    assert.equal(divergenceMarker({ ...base, type: 'macd_wave' }).symbolSize, 9)
  }
})

test('M1 is restricted to confirmed waves with a later actual confirmation', () => {
  const base = { bc: true, type: 'macd_wave', status: 'confirmed', direction: 'down',
    signal_index: 10, confirmed_index: 13, curr_date: '2026-09-11', confirmed_date: '2026-09-16' }
  for (const direction of ['up', 'down']) {
    const event = { ...base, direction }
    assert.deepEqual(macdPrompts([event]), [event])
  }
  for (const change of [{ type: 'qs' }, { type: 'macd' }, { status: 'candidate' },
    { status: 'superseded' }, { bc: false }, { confirmed_index: 10 },
    { confirmed_index: null }, { signal_index: -1 }, { direction: undefined },
    { confirmed_date: null }]) {
    assert.deepEqual(macdPrompts([{ ...base, ...change }]), [])
  }
})
