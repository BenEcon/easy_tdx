from datetime import datetime, timedelta

import pandas as pd

from easy_tdx.chanlun.observation_context import line_pair, ma_context, linkage_context
from easy_tdx.chanlun.observation_context import pen_context, repair_events
from easy_tdx.chanlun.analyser import ChanlunAnalyser
from easy_tdx.web.routers.chanlun_observations import StudyRequest, observations


def dates(n):
    return pd.Series([datetime(2026, 1, 1)+timedelta(days=i) for i in range(n)])


def test_distance_is_not_signed_gap_and_crossing_is_not_forecast():
    below = line_pair(pd.Series([-3., -2.]), pd.Series([0., 0.]), dates(2))
    above = line_pair(pd.Series([1., 2.]), pd.Series([0., 0.]), dates(2))
    assert below['gap_change'] == above['gap_change'] == 1
    assert below['distance_state'] == '距离缩小'
    assert above['distance_state'] == '距离扩大'
    assert below['last_crossing'] is None
    crossed = line_pair(pd.Series([-1., 0., 1.]), pd.Series([0., 0., 0.]), dates(3))
    assert crossed['state'] == '刚上穿' and crossed['last_crossing']['index'] == 2
    assert line_pair(pd.Series([1.]), pd.Series([float('nan')]), dates(1))['state'] == '样本不足'


def test_ma_order_strict_and_history_causal():
    close = pd.Series(range(1, 50), dtype=float)
    result = ma_context(close, dates(len(close)))
    assert result['state'] == '多头排列'
    assert result['transitions'][1]['index'] == 29
    assert ma_context(-close, dates(len(close)))['state'] == '空头排列'
    assert ma_context(close*0+10, dates(len(close)))['state'] == '交错排列'
    for n in range(1, len(close)+1):
        current = ma_context(close[:n], dates(n))
        assert current['transitions'] == [r for r in result['transitions'] if r['index'] < n]


def test_asynchronous_crossings_keep_separate_times():
    pair1 = line_pair(pd.Series([-1., 1., 1.]), pd.Series([0., 0., 0.]), dates(3))
    pair2 = line_pair(pd.Series([-1., -1., 1.]), pd.Series([0., 0., 0.]), dates(3))
    result = linkage_context({'ma': pair1, 'volume': pair2, 'macd': pair2})
    assert result['state'] == '三组快线均在慢线上方'
    assert [e['index'] for e in result['timeline']] == [1, 2, 2]


def test_open_bar_and_everything_after_it_are_excluded():
    bars = [dict(datetime=d, open=10, close=10, high=11, low=9, vol=100,
                 is_closed=i != 2) for i, d in enumerate(dates(5))]
    result = observations(StudyRequest(as_of=datetime(2026, 2, 1), series=[
        dict(code='600699', category='DAY', bars=bars)]))
    row = result['rows'][0]
    assert row['bar_count'] == 2 and row['excluded_bars'] == 3
    assert not row['eligible_for_trading'] and not row['pen_observation']['formal_pen']


def test_observation_does_not_change_formal_structure():
    frame = pd.DataFrame([dict(datetime=d, open=10+i%4, close=10+i%4,
                              high=11+i%4, low=9+i%4, vol=100) for i,d in enumerate(dates(40))])
    result = ChanlunAnalyser().process_klines(frame)
    before = [(b.start.val, b.end.val, b.confirmed_index) for b in result.bis]
    context = pen_context(result)
    assert not context['formal_pen'] and context.get('known_date')
    assert [(b.start.val, b.end.val, b.confirmed_index) for b in result.bis] == before


def test_repair_events_do_not_backdate_histogram_shrinkage():
    from types import SimpleNamespace
    result = SimpleNamespace(macd={'hist':[-4,-3,-2,-1,1]}, bcs=[])
    events = repair_events(result, {}, dates(5))
    assert len(events) == 1 and events[0]['index'] == 2
    assert not repair_events(SimpleNamespace(macd={'hist':[-4,-3]}, bcs=[]), {}, dates(2))
