"""Descriptive chart context, independent of divergence and structural admission."""
from math import isfinite

import pandas as pd

from easy_tdx.chanlun.anchors import extreme_index
from easy_tdx.chanlun.bi import _first_observable


def number(value):
    return float(value) if pd.notna(value) and isfinite(value) else None


def line_pair(fast, slow, dates):
    """Unsigned distance is distinct from signed momentum and forecast crosses."""
    f, s = number(fast.iloc[-1]), number(slow.iloc[-1])
    result = {'state': '样本不足', 'fast': f, 'slow': s,
              'distance_state': '样本不足', 'crossings': []}
    if len(fast) < 2 or any(number(x) is None for x in (fast.iloc[-2], slow.iloc[-2], f, s)):
        return result
    gap, prev = f - s, float(fast.iloc[-2] - slow.iloc[-2])
    result.update(state=('刚上穿' if gap > 0 >= prev else '刚下穿' if gap < 0 <= prev else
                         '快线上方' if gap > 0 else '快线下方' if gap < 0 else '双线相等'),
                  gap=gap, distance=abs(gap), gap_change=gap-prev,
                  distance_change=abs(gap)-abs(prev),
                  fast_slope=f-float(fast.iloc[-2]), slow_slope=s-float(slow.iloc[-2]))
    result['distance_state'] = ('发生交叉' if gap * prev < 0 else '双线重合' if gap == 0 else
                                '距离缩小' if abs(gap) < abs(prev) else
                                '距离扩大' if abs(gap) > abs(prev) else '距离持平')
    for i in range(1, len(fast)):
        values = [number(x) for x in (fast.iloc[i], slow.iloc[i], fast.iloc[i-1], slow.iloc[i-1])]
        if None in values:
            continue
        a, b, c, d = values
        side = 'up' if a > b and c <= d else 'down' if a < b and c >= d else None
        if side:
            result['crossings'].append({'index': i, 'date': str(dates.iloc[i]), 'direction': side})
    result['last_crossing'] = result['crossings'][-1] if result['crossings'] else None
    result['crossings'] = result['crossings'][-20:]
    return result


def ma_context(close, dates):
    periods = [5, 10, 20, 30]
    series = {p: close.rolling(p).mean() for p in periods}
    rows, previous, has_bull = [], None, False
    for i in range(len(close)):
        values = [number(series[p].iloc[i]) for p in periods]
        if None in values:
            state = '样本不足'
        elif all(a > b for a, b in zip(values, values[1:])):
            state = '多头排列'
            has_bull = True
        elif all(a < b for a, b in zip(values, values[1:])):
            state = '空头排列'
        elif values[0] > values[1]:
            state = '修复观察 · 尚未多头排列'
        elif has_bull and values[0] < values[1]:
            state = '多头排列后走弱'
        else:
            state = '交错排列'
        if state != previous:
            rows.append({'index': i, 'date': str(dates.iloc[i]), 'state': state})
            previous = state
    return {'periods': periods, 'values': {str(p): number(series[p].iloc[-1]) for p in periods},
            'state': previous, 'transitions': rows[-20:],
            'policy': '严格比较 MA5/10/20/30；相等不算多头或空头；修复观察不保证完成，不随图层开关改变'}


def pen_context(result):
    """An observed fractal suggests a direction, never appends a structural pen."""
    if not result.fractals:
        return {'state': '尚无已形成分型', 'formal_pen': False}
    start = result.fractals[-1]
    at = extreme_index(start)
    reverse = 'up' if start.fx_type.value == 'di' else 'down'
    subsequent = result.klines[at+1:]
    if not subsequent:
        return {'state': '分型后样本不足', 'formal_pen': False}
    up = reverse == 'up'
    end = max(subsequent, key=lambda k: k.high) if up else min(subsequent, key=lambda k: k.low)
    broken = any(k.low < start.val if up else k.high > start.val for k in subsequent)
    return {'state': '分型锚点已被突破' if broken else '向上发展观察' if up else '向下发展观察',
            'direction': reverse, 'anchor_index': at, 'anchor_date': str(result.klines[at].date),
            'anchor_price': start.val, 'known_date': str(result.klines[_first_observable(start)].date),
            'extreme_date': str(end.date), 'extreme_price': end.high if up else end.low,
            'formal_pen': False,
            'policy': '从最后已形成分型观察潜在方向；未有相反分型及严格间距验证，不加入笔、线段、中枢或递归；后续可延伸或失效'}


def linkage_context(pairs):
    timeline = sorted([dict(event, source=source) for source, pair in pairs.items()
                       for event in pair.get('crossings', [])], key=lambda e: (e['index'], e['source']))
    available = all(pair.get('gap') is not None for pair in pairs.values())
    state = ('三组快线均在慢线上方' if available and all(p['gap'] > 0 for p in pairs.values()) else
             '三组快线均在慢线下方' if available and all(p['gap'] < 0 for p in pairs.values()) else
             '三组状态不同步' if available else '样本不足')
    return {'state': state, 'timeline': timeline[-30:],
            'policy': '分别记录 MA5/10、MAVOL5/10、DIF/DEA 的实际交叉时刻；距离缩小不等于即将交叉，历史先后不证明因果，不生成 M1/1M/1S'}


def repair_events(result, pairs, dates):
    """Timestamped facts, not a prescribed small-to-large reversal sequence."""
    events = []
    hist = result.macd['hist']
    was_shrinking = False
    for i in range(2, len(hist)):
        shrinking = all(h < 0 for h in hist[i-2:i+1]) and abs(hist[i]) < abs(hist[i-1]) < abs(hist[i-2])
        if shrinking and not was_shrinking:
            events.append({'index': i, 'date': str(dates.iloc[i]), 'kind': 'green_shrinking',
                           'label': '绿柱连续两根缩短', 'status': 'observed'})
        was_shrinking = shrinking
    for name, pair in pairs.items():
        for cross in pair.get('crossings', []):
            if cross['direction'] == 'up':
                events.append(dict(cross, kind=f'{name}_cross_up', status='observed',
                                   label={'ma': 'MA5 上穿 MA10', 'volume': 'MAVOL5 上穿 MAVOL10',
                                          'macd': 'DIF 上穿 DEA'}[name]))
    for event in result.bcs:
        if event.direction == 'down' and event.status == 'confirmed' and event.confirmed_index is not None:
            events.append({'index': event.confirmed_index, 'date': str(dates.iloc[event.confirmed_index]),
                           'signal_date': str(dates.iloc[event.signal_index]),
                           'kind': event.bc_type.value, 'label': '底背离确认', 'status': 'confirmed'})
    return sorted(events, key=lambda e: (e['index'], e['kind']))[-40:]
