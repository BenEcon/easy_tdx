import test from 'node:test'
import assert from 'node:assert/strict'
import { divergenceEvidence, waveFailureSummary, waveDiagnosticLines } from '../src/divergence-evidence.ts'

test('wave evidence separates effective A from original wave and local pivots', () => {
  const lines = divergenceEvidence({ type: 'macd_wave', evidence: { a_axis_trimmed: 1 },
    intervals: { original_a_start: '2025-09-30', original_a_end: '2025-12-05', a_start: '2025-11-14' } })
  assert.ok(lines.some(s => s.includes('不要求最近局部极值')))
  assert.ok(lines.some(s => s.includes('2025-09-30') && s.includes('2025-11-14')))
  assert.ok(!lines.some(s => s.includes('同时核验最近局部极值')))
})

test('unformed candidate shows Chinese gates, two-decimal values and rejection dates', () => {
  const record = { closed: true, dates: { known_index: '2026-01-08', c_start: '2026-01-06', c_end: '2026-01-07' },
    checks: [{ gate: 'shrinking_same_colour_area', passed: false, values: { a_area: 1.123456, c_area: 3.23456 } }],
    rejections: [{ from_date: '2026-01-06', through_date: '2026-01-08', gates: ['shrinking_same_colour_area'] }] }
  assert.equal(waveFailureSummary(record), 'C 同色柱面积未小于有效 A')
  const lines = waveDiagnosticLines(record)
  assert.ok(lines.some(s => s.includes('1.12 → 3.23')))
  assert.ok(lines.some(s => s.includes('拦截记录 2026-01-06 — 2026-01-08')))
  assert.ok(!lines.join('').includes('shrinking_same_colour_area'))
})
