import type { ECharts } from 'echarts/core'

/** Disable ECharts' hover/leave handlers; the selected date stays until dismissed. */
export const clickTooltipOptions = {
  triggerOn: 'none',
  hideDelay: 0,
  enterable: false,
} as const

export function installClickChartTooltip(chart: ECharts, container: HTMLElement) {
  const document = container.ownerDocument
  const renderer = chart.getZr()
  function hide() {
    chart.dispatchAction({ type: 'updateAxisPointer', currTrigger: 'leave' })
    chart.dispatchAction({ type: 'hideTip' })
  }
  function select(event: { offsetX: number; offsetY: number }) {
    hide()
    // Coordinates also support blank space between candles and marker tooltips.
    // ECharts resolves the date and retains each existing formatter/style.
    chart.dispatchAction({ type: 'showTip', x: event.offsetX, y: event.offsetY })
  }
  function dismissOutside(event: Event) {
    if (!event.composedPath().includes(container)) hide()
  }
  function dismissWithEscape(event: KeyboardEvent) {
    if (event.key === 'Escape') hide()
  }
  renderer.on('click', select)
  chart.on('datazoom', hide)
  document.addEventListener('click', dismissOutside, true)
  document.addEventListener('keydown', dismissWithEscape)
  return {
    hide,
    dispose() {
      renderer.off('click', select)
      chart.off('datazoom', hide)
      document.removeEventListener('click', dismissOutside, true)
      document.removeEventListener('keydown', dismissWithEscape)
    },
  }
}
