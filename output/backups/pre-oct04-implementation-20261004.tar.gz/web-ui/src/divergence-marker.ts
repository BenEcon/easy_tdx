import type { ChanlunDivergence } from './types'

/** A display subtype, not a second event or a relaxed wave-divergence rule. */
export function isSpecialDualLine(item: ChanlunDivergence) {
  return item.type === 'macd' && item.evidence?.special_no_c === 1
    && (item.direction === 'up' || item.direction === 'down')
}

/** Preserve every audit record; suppress only a redundant dual-line chart mark. */
export function visibleDivergences(items: ChanlunDivergence[]) {
  const active = items.filter(item => item.bc && item.status !== 'superseded')
  const specialSlots = new Set(active.filter(item => item.type === 'macd_wave_special')
    .map(item => `${item.signal_index}:${item.direction}`))
  return active.filter(item => !(item.type === 'macd'
    && specialSlots.has(`${item.signal_index}:${item.direction}`)))
}

/** Presentation-only MACD prompts; never append them to structural mmds. */
export function macdPrompts(items: ChanlunDivergence[]) {
  return items.filter(item => item.bc && item.type === 'macd_wave' && item.status === 'confirmed'
    && (item.direction === 'up' || item.direction === 'down')
    && Number.isInteger(item.signal_index) && item.signal_index! >= 0
    && Number.isInteger(item.confirmed_index) && item.confirmed_index! > item.signal_index!
    && item.curr_date && item.confirmed_date)
}

/** Direction, family and lifecycle are separate visual channels. */
export function divergenceMarker(item: ChanlunDivergence) {
  if (!item.bc || item.status === 'superseded') return null
  const candidate = item.status === 'candidate'
  const special = isSpecialDualLine(item) || item.type === 'macd_wave_special'
  // A special diamond can fill only with a later, recorded reverse-pen witness.
  const hollow = special ? !(item.status === 'confirmed'
    && Number.isInteger(item.signal_index) && item.signal_index! >= 0
    && Number.isInteger(item.confirmed_index) && item.confirmed_index! > item.signal_index!
    && item.evidence?.reverse_pen_start === item.signal_index
    && item.evidence?.reverse_pen_confirmed === item.confirmed_index) : candidate
  const color = item.type === 'macd_wave_nonstandard' ? '#ff6577'
    : item.direction === 'up' ? '#61dfa0' : '#cf8ff5'
  return {
    symbol: item.type === 'macd' && !special ? 'circle' : 'diamond',
    symbolSize: special ? 13 : 9,
    itemStyle: {
      color: hollow ? 'transparent' : color,
      borderColor: color,
      borderWidth: 1.5,
      borderType: hollow ? 'dashed' : 'solid',
    },
    label: { show: false },
  }
}
